<style type="text/css">
<!--
.style1 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 24px;
	
}
.style1 {
}
-->
</style>
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'none')
          e.style.display = 'block';
       else
          e.style.display = 'none';
    }
//-->
</script>
<link rel="stylesheet" href="modules/account/news/lightbox/css/default.css" media="screen,projection" type="text/css" />
<link rel="stylesheet" href="modules/account/news/lightbox/css/lightbox.css" media="screen,projection" type="text/css" />

<!-- JavaScript -->
<script type="text/javascript" src="modules/account/news/lightbox/scripts/prototype.js"></script>
<script type="text/javascript" src="modules/account/news/lightbox/scripts/lightbox.js"></script>
 <script type="text/javascript">
 function showUser(str)
{
if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","modules/account/news/getinfo.php?q="+str,true);
xmlhttp.send();
}
</script>
<?php include('lang/' .GetSystemOption('zpanel_lang'). '.php'); ?>
<div align="left">
<p>

</p>
<table width="720" border="0">
  <tr>
    <td width="400"><span class="style1"><?php echo $lang['nu18'] ?></span></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;
    <table align="left">

<?php do{ ?>
 <tr>
    <td align="center" valign="top"><img src="modules/account/news/images/news-icon[1].gif" width="20" height="20" align="top"></td>
    <td><a href="#" onClick="toggle_visibility('<?php echo $row_news['nu_title']; ?>');"><strong><?php echo Cleaner('o',$row_news['nu_title']); ?></strong></a>
<div id="<?php echo $row_news['nu_title']; ?>" style="display:none;"><?php echo Cleaner('o',$row_news['summary']). '<a href="modules/account/news/getinfo.php?q=' . $row_news['nu_id'] . '" class="lbOn"><b>'.$lang['nu20'].'</b></a>'; ?><br><br></div></td>
  </tr>
<?php } while ($row_news = mysql_fetch_assoc($news)); ?>	
</table></td>
  </tr>
  <tr>
    <td align="left" valign="top"><span class="style1"><?php echo $lang['nu19'] ?></span></td>
  </tr>
  <tr>
    <td align="left" valign="top"><table align="left">

<?php do{ ?>
 <tr>
    <td align="center" valign="top"><img src="modules/account/news/images/update.gif" width="20" height="20"></td>
    <td><a href="#" onClick="toggle_visibility('<?php echo $row_updates['nu_title']; ?>');"><strong><?php echo Cleaner('o',$row_updates['nu_title']); ?></strong></a>
<div id="<?php echo $row_updates['nu_title']; ?>" style="display:none;"><?php echo Cleaner('o',$row_updates['summary']). '<a href="modules/account/news/getinfo.php?q=' . $row_updates['nu_id'] . '" class="lbOn"><b>'.$lang['nu20'].'</b></a>'; ?><br><br></div></td>
  </tr>
<?php } while ($row_updates = mysql_fetch_assoc($updates)); ?>	
</td>
  </tr></table>
</table>
<div id="txtHint"></div>
