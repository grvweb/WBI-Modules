<?php
#############################################################
# this file is or develpor uses only                        #
# it is just another working version                        #
# of getinfo.php                                            #
#                                                           #
#                                                           #
#                                                           #
#                                                           #
#                                                           #
#                                                           #
#############################################################

?>
<?php require_once('../../../conf/zcnf.php'); ?>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_information = "-1";
if (isset($_GET['q'])) {
  $colname_information = $_GET['q'];
}
mysql_select_db($z_db_name, $zdb);
$query_information = sprintf("SELECT * FROM z_news_updates WHERE nu_id = %s", GetSQLValueString($colname_information, "int"));
$information = mysql_query($query_information, $zdb) or die(mysql_error());
$row_information = mysql_fetch_assoc($information);
$totalRows_information = mysql_num_rows($information);


?>

<table border="1">
  <tr>
    <td>nu_description</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_information['nu_description']; ?></td>
    </tr>
    <?php } while ($row_information = mysql_fetch_assoc($information)); ?>
</table>
<?php
mysql_free_result($information);
?>