<?php
include('conf/zcnf.php');
include('lang/' .GetSystemOption('zpanel_lang'). '.php');
?>

<?php require_once('conf/zcnf.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_news = 10;
$pageNum_news = 0;
if (isset($_GET['pageNum_news'])) {
  $pageNum_news = $_GET['pageNum_news'];
}
$startRow_news = $pageNum_news * $maxRows_news;

mysql_select_db($z_db_name, $zdb);
$query_news = "SELECT * FROM z_news_updates WHERE nu_type = 'news'";
$query_limit_news = sprintf("%s LIMIT %d, %d", $query_news, $startRow_news, $maxRows_news);
$news = mysql_query($query_limit_news, $zdb) or die(mysql_error());
$row_news = mysql_fetch_assoc($news);

if (isset($_GET['totalRows_news'])) {
  $totalRows_news = $_GET['totalRows_news'];
} else {
  $all_news = mysql_query($query_news);
  $totalRows_news = mysql_num_rows($all_news);
}
$totalPages_news = ceil($totalRows_news/$maxRows_news)-1;

mysql_select_db($z_db_name, $zdb);
$query_updates = "SELECT * FROM z_news_updates WHERE nu_type = 'update'";
$updates = mysql_query($query_updates, $zdb) or die(mysql_error());
$row_updates = mysql_fetch_assoc($updates);
$totalRows_updates = mysql_num_rows($updates);

$colname_Recordset1 = "-1";
if (isset($_COOKIE['newsid'])) {
  $colname_Recordset1 = $_COOKIE['newsid'];
}

mysql_select_db($z_db_name, $zdb);
$query_Recordset1 = sprintf("SELECT * FROM z_news_updates WHERE nu_id = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $zdb) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
/*
$news = wordwrap($row_news['nu_description'], 80, "<br />\n");
$updatess = wordwrap($row_updates['nu_description'], 80, "<br />\n");
*/ 
?>


<table width="200" border="0">
  <tr>
    <td>
    <?php echo $lang['nu17'] ?>
<p><br/>
    <a href="./?c=account&amp;p=news&amp;layout=1"><img src="modules/account/news/images/icon layout 1.png" alt="layout 1" align="left" /></a> 
   <a href="./?c=account&amp;p=news&amp;layout=2"><img src="modules/account/news/images/icon layout 2.png" alt="layout 2" align="left" /></a><br/>
  <br/>
  <br/>
  <?php 
if ($_GET['layout'] == 1){

include ('modules/account/news/layout1.php');
}else if ($_GET['layout'] == 2){


include ('modules/account/news/layout2.php');


}else{
include ('modules/account/news/layout1.php');
}
    ?>
    
    
    
    </td>
  </tr>
</table>

  <?php mysql_free_result($updates);
mysql_free_result($news); ?>

