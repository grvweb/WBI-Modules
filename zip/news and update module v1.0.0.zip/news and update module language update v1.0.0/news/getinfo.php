<?php
include ("../../../conf/zcnf.php");

$q=$_GET["q"];
mysql_select_db($database_zdb , $zdb);

$sql="SELECT * FROM z_news_updates WHERE nu_id = '".$q."'"; 

$result = mysql_query($sql) or die(mysql_error()) ;
//divlightbox
//
?>
<style type="text/css">
<!--
.style1 {font-size: 24px}
-->
</style>

<div style="height:400px;width:900px;overflow-x:hidden;overflow-y:scroll;">
<?php
echo "<table border='0'>";

while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['nu_description'] . "</td>";
  echo "</tr>";
  }
echo "</table>";
?>
<br/>
<br/>
</div>
<span class="style1"><br/>
<a href="#" class="lbAction" rel="deactivate"><strong><?php echo $lang['nu21'] ?>.</strong></a></span>


<br/>

<?php
//mysql_close($con);
?>