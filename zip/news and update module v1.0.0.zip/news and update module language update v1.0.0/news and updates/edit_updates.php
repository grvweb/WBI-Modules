<?php require_once('conf/zcnf.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE z_news_updates SET nu_title=%s, summary=%s, nu_description=%s, nu_type=%s, nu_add_by=%s WHERE nu_id=%s",
                       GetSQLValueString($_POST['nu_title'], "text"),
                       GetSQLValueString($_POST['summary'], "text"),
                       GetSQLValueString($_POST['nu_description'], "text"),
                       GetSQLValueString($_POST['nu_type'], "text"),
                       GetSQLValueString($_POST['nu_add_by'], "text"),
                       GetSQLValueString($_POST['nu_id'], "int"));

  mysql_select_db($z_db_name, $zdb);
  $Result1 = mysql_query($updateSQL, $zdb) or die(mysql_error());

  $updateGoTo = "index.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  //header(sprintf("Location: %s", $updateGoTo));
    echo '
<script type="text/javascript">

window.location = "./?c=admin&p=news and updates"

</script>';
}

$colname_update = "-1";
if (isset($_GET['id'])) {
  $colname_update = $_GET['id'];
}
mysql_select_db($database_zdb, $zdb);
$query_update = sprintf("SELECT * FROM z_news_updates WHERE nu_id = %s", GetSQLValueString($colname_update, "int"));
$update = mysql_query($query_update, $zdb) or die(mysql_error());
$row_update = mysql_fetch_assoc($update);
$totalRows_update = mysql_num_rows($update);

$maxRows_list_updates = 10;
$pageNum_list_updates = 0;
if (isset($_GET['pageNum_list_updates'])) {
  $pageNum_list_updates = $_GET['pageNum_list_updates'];
}
$startRow_list_updates = $pageNum_list_updates * $maxRows_list_updates;

mysql_select_db($database_zdb, $zdb);
$query_list_updates = "SELECT nu_id, nu_title FROM z_news_updates WHERE nu_type = 'update'";
$query_limit_list_updates = sprintf("%s LIMIT %d, %d", $query_list_updates, $startRow_list_updates, $maxRows_list_updates);
$list_updates = mysql_query($query_limit_list_updates, $zdb) or die(mysql_error());
$row_list_updates = mysql_fetch_assoc($list_updates);

if (isset($_GET['totalRows_list_updates'])) {
  $totalRows_list_updates = $_GET['totalRows_list_updates'];
} else {
  $all_list_updates = mysql_query($query_list_updates);
  $totalRows_list_updates = mysql_num_rows($all_list_updates);
}
$totalPages_list_updates = ceil($totalRows_list_updates/$maxRows_list_updates)-1;
?>
<?php if ($totalRows_list_updates > 0) { // Show if recordset not empty ?>
  <center><table border="1">
    <tr>
      <td><?php echo $lang['nu12'] ?></td>
      <td><?php echo $lang['nu7'] ?></td>
      <td></td>
      <td></td>
    </tr>
    <?php do { ?>
      <tr>
        <td><?php echo $row_list_updates['nu_id']; ?></td>
        <td><?php echo $row_list_updates['nu_title']; ?></td>
        <td><a href="./?c=admin&p=news and updates&edit=1&edit_updates=1&id=<?php echo $row_list_updates['nu_id']; ?>"><b><?php echo $lang['nu13'] ?></b></a></td>
        <td><a href="modules/admin/news and updates/delete.php?id=<?php echo $row_list_updates['nu_id']; ?>"><b><?php echo $lang['nu14'] ?></b></a></td>
      </tr>
      <?php } while ($row_list_updates = mysql_fetch_assoc($list_updates)); ?>
  </table></center>
  <?php } // Show if recordset not empty ?>
<?php 

if (isset($_GET['id'])){

echo '

<form action="' . $editFormAction . '" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">'.$lang['nu7'].':</td>
      <td><input type="text" name="nu_title" value="' .  htmlentities($row_update['nu_title'], ENT_COMPAT, '') . '" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="top">'.$lang['nu8'].':</td>
      <td><textarea name="summary" cols="50" rows="5">' . htmlentities($row_update['summary'], ENT_COMPAT, '') . '</textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="top">'.$lang['nu9'].':</td>
      <td><textarea name="nu_description" cols="50" rows="5">' . htmlentities($row_update['nu_description'], ENT_COMPAT, '') . '</textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="'.$lang['nu15'].'" /></td>
    </tr>
  </table>
  <input type="hidden" name="nu_type" value="' . htmlentities($row_update['nu_type'], ENT_COMPAT, '') . '" />
  <input type="hidden" name="nu_add_by" value="' . htmlentities($row_update['nu_add_by'], ENT_COMPAT, '') . '" />
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="nu_id" value="' . $row_update['nu_id'] . '" />
</form>
';
if ($_GET['edit_updates'] == 1){
echo '
<center><b><a href="./?c=admin&p=news and updates&edit=1&edit_news=0&id=' . $_GET['id'] . '">-'.$lang['nu10'].'-</a></b></center>
';
} else {

echo '<center><b><a href="./?c=admin&p=news and updates&edit=1&edit_news=1&id=' . $_GET['id'] . '">-'.$lang['nu11'].'-</a></b></center>';
 
}}
?>
<br/>
<?php if ($totalRows_list_updates == 0) { // Show if recordset empty ?>
  <span style="font-weight: bold; font-size: 18px"><?php echo $lang['nu16'] ?></span>
  <?php } // Show if recordset empty ?>

<?php
mysql_free_result($update);

mysql_free_result($list_updates);
?>