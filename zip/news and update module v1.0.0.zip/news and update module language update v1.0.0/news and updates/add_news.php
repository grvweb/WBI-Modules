
<?php require_once('conf/zcnf.php'); ?>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO z_news_updates (nu_title, nu_description, summary, nu_type, nu_add_by) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['nu_title'], "text"),
                       GetSQLValueString($_POST['nu_description'], "text"),
                       GetSQLValueString($_POST['summary'], "text"),
                       GetSQLValueString($_POST['nu_type'], "text"),
                       GetSQLValueString($_POST['nu_add_by'], "text"));

  mysql_select_db($z_db_name, $zdb);
  $Result1 = mysql_query($insertSQL, $zdb) or die(mysql_error());

  $insertGoTo = "index.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
    echo '
  <script type="text/javascript">
<!--
window.location = "' . $yoursiteurl . '"
//-->
</script>';
}
?>

<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><?php echo $lang['nu7'] ?>:</td>
      <td><input type="text" name="nu_title" value="" size="32" /></td>
    </tr>
     <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="top"><?php echo $lang['nu8'] ?>:</td>
      <td><textarea name="summary" cols="50" rows="5"></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="top"><?php echo $lang['nu9'] ?></td>
      <td><textarea name="nu_description" cols="50" rows="5"></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insert record" /></td>
    </tr>
  </table>
  <input type="hidden" name="nu_type" value="news" />
  <input type="hidden" name="nu_add_by" value="<?php echo $_SESSION['zUsername'] ?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<?php if ($_GET['news'] == 1){
echo '
<center><b><a href="./?c=admin&amp;p=news and updates&amp;news=0&add=1">-'.$lang['nu10'].'-</a></b></center>
';
} else {

echo '<center><b><a href="./?c=admin&amp;p=news and updates&amp;news=1&add=1">-'.$lang['nu11'].'-</a></b></center>';

}
?>