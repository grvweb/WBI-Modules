<?php
/* News & Update Lanuguage File */
$lang['nu1'] = "ADD News or Updates";
$lang['nu2'] = "Disk space:";
$lang['nu3'] = "Disk space:";
$lang['nu4'] = "Disk space:";
$lang['nu5'] = "Disk space:";
$lang['nu6'] = "Disk space:";
$lang['nu7'] = "Disk space:";
$lang['nu8'] = "Disk space:";
$lang['nu9'] = "Disk space:";
$lang['nu10'] = "Disk space:";
$lang['nu11'] = "Disk space:";
$lang['nu12'] = "Disk space:";
$lang['nu13'] = "Disk space:";
$lang['nu14'] = "Disk space:";
$lang['nu15'] = "Disk space:";
$lang['nu16'] = "Disk space:";
?>