<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# ZPANEL MODULE CONFIGURATION FILE                                           #
# --------------------------------                                           #
# this modula was develpode by Sam Mottley if you have any inquires please   #
# email me at sammottley@gmail.com                                           #
# i hope this modula help you                                                #
##############################################################################


#####################################################################################				
$thismod['title'] = 'Add News and Updates';											    #
$thismod['icon'] = 'icon.png';														#
$thismod['developer'] = 'Sam Mottley (sammottley@gmail.com)';						#
$thismod['developersite'] = 'http://www.motterswebs.tk';							#
#####################################################################################
?>											