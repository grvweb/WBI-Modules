<?php require_once('conf/zcnf.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO z_news_updates (nu_title, summary, nu_description, nu_type, nu_add_by) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['nu_title'], "text"),
                       GetSQLValueString($_POST['summary'], "text"),
                       GetSQLValueString($_POST['nu_description'], "text"),
                       GetSQLValueString($_POST['nu_type'], "text"),
                       GetSQLValueString($_POST['nu_add_by'], "text"));

  mysql_select_db($z_db_name, $zdb);
  $Result1 = mysql_query($insertSQL, $zdb) or die(mysql_error());
}

mysql_select_db($z_db_name, $zdb);
$query_Recordset1 = "SELECT * FROM z_news_updates";
$Recordset1 = mysql_query($query_Recordset1, $zdb) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);









mysql_free_result($Recordset1);
?>
 
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right"><?php echo $lang['nu7'] ?>:</td>
      <td><input type="text" name="nu_title" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right"><?php echo $lang['nu8'] ?></td>
      <td><textarea name="summary" cols="32"></textarea></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right"><?php echo $lang['nu9'] ?>:</td>
      <td><textarea name="nu_description" cols="32"></textarea></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="Insert record"></td>
    </tr>
  </table>
  <input type="hidden" name="nu_type" value="update">
  <input type="hidden" name="nu_add_by" value="<?php echo $_SESSION['zUsername'] ?>">
  <input type="hidden" name="MM_insert" value="form1">
</form>
<p>&nbsp;</p>
<?php if ($_GET['updates'] == 1){
echo '
<center><b><a href="./?c=admin&amp;p=news and updates&amp;news=0&add=1">-'.$lang['nu10'].'-</a></b></center>
';
} else {

echo '<center><b><a href="./?c=admin&amp;p=news and updates&amp;news=1&add=1">-'.$lang['nu11'].'-</a></b></center>';

}
?>