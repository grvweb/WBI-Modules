<?php 
include('lang/' .GetSystemOption('zpanel_lang'). '.php');
ob_start(); ?>
<a href="./?c=admin&p=news and updates&add=1">|| <?php echo $lang['nu1'] ?> ||</a></p>
<p>
<?php if (isset($_GET['add'])){ echo '<p>--> <a href="./?c=admin&p=news and updates&news=1&add=1">|| '.$lang['nu2'].' ||</a> <a href="./?c=admin&p=news and updates&updates=1&add=1"> || '.$lang['nu3'].' ||</a></p>
';}
?>
<p>
  <?php

if($_GET['news'] == '0'){
include ("modules/admin/news and updates/add_news.php");
} else if ($_GET['news'] == '1'){
include ("modules/admin/news and updates/editor.html");
include ("modules/admin/news and updates/add_news.php");
}

?>
  
  <?php
if($_GET['updates'] == '0'){
include ("modules/admin/news and updates/add_updates.php");
} else if ($_GET['updates'] == '1'){
include ("modules/admin/news and updates/editor.html");
include ("modules/admin/news and updates/add_updates.php");
}
?>
  
  <br/>
  <br/>
<a href="./?c=admin&p=news and updates&edit=1">|| <?php echo $lang['nu4'] ?> ||</a></p>
<p>
  <?php if (isset($_GET['edit'])){ echo '
<p>--> <a href="./?c=admin&p=news and updates&edit=1&edit_news=1">|| '.$lang['nu5'].' ||</a> 
<a href="./?c=admin&p=news and updates&edit=1&edit_updates=1"> || '.$lang['nu6'].' ||</a></p>

';}
?>
  <?php

if($_GET['edit_news'] == '0'){
include ("modules/admin/news and updates/edit_news.php");
} else if ($_GET['edit_news'] == '1'){
include ("modules/admin/news and updates/editor.html");
include ("modules/admin/news and updates/edit_news.php");
}

?>
  
</p>
<?php
if($_GET['edit_updates'] == '0'){
include ("modules/admin/news and updates/edit_updates.php");
} else if ($_GET['edit_updates'] == '1'){
include ("modules/admin/news and updates/editor.html");
include ("modules/admin/news and updates/edit_updates.php");
}
?>