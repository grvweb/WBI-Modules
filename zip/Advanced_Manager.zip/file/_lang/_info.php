<OPTION value="en">English</OPTION>
<OPTION value="de">Deutsch</OPTION>
<OPTION value="es">Espa�ol</OPTION>
<OPTION value="fr">Fran�ais</OPTION>
<OPTION value="nl">Nederlands</OPTION>
<OPTION value="ru">Russian</OPTION>