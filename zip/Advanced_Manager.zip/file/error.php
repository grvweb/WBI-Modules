<?php
echo "Please access this page from the control panel.";
?>