<?php

$val = $_GET['word'];
setcookie("files123", $val, time()+6000);
header("Location: /apps/file/index.php");

?>