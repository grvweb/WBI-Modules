<?php
include('conf/zcnf.php');
include('lang/' .GetSystemOption('zpanel_lang'). '.php');
include('inc/zAccountDetails.php');

$url = "/apps/file/user.php?word=C:/ZPanel/hostdata/";
$user = $_SESSION['zUsername'];

Echo "Launch the file manager below to upload, modify, change or delete your files & folders. <BR><BR>";
Echo "<Script Language=\"JavaScript\">
<!--
function load() {
var load = window.open('$url$user','','');
}
// -->
</Script>
<B>
<a href=\"javascript:load()\">&raquo; Launch File Manager</a></B>";
?>