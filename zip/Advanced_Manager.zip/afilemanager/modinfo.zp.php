<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# ZPANEL MODULE CONFIGURATION FILE                                           #
# --------------------------------                                           #
# This module was developed by Tyler Harris. If you have any inquires please #
# email me at tysmailbox@gmail.com                                           #
##############################################################################


#####################################################################################				
$thismod['title'] = 'File Manager';													#
$thismod['icon'] = 'icon.png';														#
#####################################################################################
?>											