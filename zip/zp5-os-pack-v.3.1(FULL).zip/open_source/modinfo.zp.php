<?php
$thismod['title'] = 'OpenSource Packs';
$thismod['icon'] = 'open_source.gif';
$thismod['developer'] = 'Patrick de Koning (patrickdekoning@pdkwebs.nl)';
$thismod['developersite'] = 'http://www.pdkwebs.nl/';
?>