<?php
$package = $_POST['package'];
$path = $_POST['path'];
$dir = $_POST['dir'];
$dirname = $_POST['dirname'];
$from_path = "C:/ZPanel/panel/modules/storage/open_source/packages/$package/";
$to_path = "$dir$path$dirname/";
$to_path2 = "$path$dirname/";
               function rec_copy($to_path, $from_path) {
                 mkdir($to_path, 0777); 
                 $this_path = getcwd(); 
                 if (is_dir($from_path)) {
				 chdir($from_path);
                     $handle=opendir('.'); 
                     while (($file = readdir($handle))!==false) {
                        if (($file != "...") && ($file != ".") && ($file != "..")) {
                             if (is_dir($file)) {
//							 if ($row_Installers['silent'] == 0) {
//								 echo ('Changing into folder '.$file.'...<br>');
//							 }
                                 rec_copy ($to_path.'/'.$file."/", $from_path.'/'.$file."/"); 
                                 chdir($from_path);
                             }
                             if (is_file($file)){ 
                                 copy($from_path.'/'.$file, $to_path.'/'.$file); 
//							 	 if ($row_Installers['silent'] == 0) {
//									 echo ('Copyed file '.$file.'...<br>');
//							 	 }
                       		 } 
                         } 
                     } 
                 closedir($handle); 
                 } 
			}
			
rec_copy($to_path, $from_path);
?>
<?PHP
$domain = str_replace("_",".",$path);
echo "<center><h2><strong>Congratulations!</strong></h2><br />Package $package is successfully copied to directory <i>$to_path2.</i><br />Go to <a href=\"http://$domain$dirname/\">http://$domain$dirname/</a> to install $package!<br /><p /><a href=\"javascript:history.back()\"><b>Return to ZPanel</b></a></center>";
?>


