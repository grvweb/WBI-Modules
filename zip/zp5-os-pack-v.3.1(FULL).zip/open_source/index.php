<?php
include('conf/zcnf.php');
include('lang/' .GetSystemOption('zpanel_lang'). '.php');
include('inc/zAccountDetails.php');

$sql = "SELECT * FROM z_vhosts WHERE vh_acc_fk=" .$useraccount['ac_id_pk']. " AND vh_deleted_ts IS NULL";
$listdomains = DataExchange("r",$z_db_name,$sql);
$rowdomains = mysql_fetch_assoc($listdomains);
$totaldomains = DataExchange("t",$z_db_name,$sql);

echo "With the Open Source Package Extractor, you can easily copy Open Source Packages like phpBB to your domain(s).<p />";

echo "<form method=\"post\" action=\"modules/storage/open_source/installer.php\">
<table class=\"zform\">
<tr>
<td><strong>Package:</strong></td>
<td>Please select which Open Source Package you want to copy.<br /><select name=\"package\">";
$dirPath01 = dir("modules/storage/open_source/packages");
while (($file01 = $dirPath01->read()) !== false)
{
	if ($file01 != "." && $file01 != "..") {
	echo "<option value=" .$file01. ">" .$file01. "</option>\n";
	}
}
$dirPath01->close();

echo "</select>
</td>
</tr>
<tr>
<td><strong>Domain:</strong></td>
<td>To which domain/directory do you want to copy the package?<br /><select name=\"path\">";
            $handle = @opendir(GetSystemOption('hosted_dir').$useraccount['ac_user_vc']);
            $chkdir = GetSystemOption('hosted_dir').$useraccount['ac_user_vc']. "/";
			if(!$handle){
				TriggerLog($useraccount['ac_id_pk'], $b="Was unable to read the folders in (" .$chkdir. "), please ensure this folder exists.");
			} else {
				while ($file = readdir($handle)) {
				if ($file != "." && $file != "..") {
				if(is_dir($chkdir.$file)) {
				echo "<option value=" .$file. ">" .$file. "</option>\n";
				}
				}
				}
				closedir($handle);
			}

echo "<tr>
<td><strong>Directory:</strong></td>
<td>You can fill in here the name of the new directory which contains the package. Leave blanc for the standard name.<br /><input type=\"text\" name=\"dirname\" size=\"28\" value=\"/\" />";

echo "<input type=\"hidden\" name=\"dir\" value=\"$chkdir\" />";
echo "<input type=\"submit\" value=\"Copy package\" />
</select>
</tr>
</table>
</form>";
?>