<?php

/**
 * This code is part of the FileManager software (www.gerd-tentler.de/tools/filemanager), copyright by
 * Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 * redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
 */

@error_reporting(E_WARNING);
@set_time_limit(600);

include_once('ListingDetail.php');
include_once('ListingIcon.php');
include_once('Image.php');
include_once('Editor.php');
include_once('Tools.php');

/**
 * This is the main class.
 */
class FileManager {

/* PUBLIC PROPERTIES *************************************************************************** */

	/* configuration variables; will be filled with content from config file */

	var $ftpHost;
	var $ftpUser;
	var $ftpPassword;
	var $ftpPort;
	var $ftpPassiveMode;
	var $language;
	var $encoding;
	var $locale;
	var $startDir;
	var $startSubDirs;
	var $startSearch;
	var $fmWebPath;
	var $fmWidth;
	var $fmHeight;
	var $fmMargin;
	var $fmView;
	var $logHeight;
	var $explorerWidth;
	var $thumbMaxWidth;
	var $thumbMaxHeight;
	var $defaultFilePermissions;
	var $defaultDirPermissions;
	var $allowFileTypes;
	var $hideFileTypes;
	var $hideSystemFiles;
	var $hideSystemType;
	var $hideFilePath;
	var $hideLinkTarget;
	var $hideDisabledIcons;
	var $enableUpload;
	var $enableDownload;
	var $enableEdit;
	var $enableDelete;
	var $enableRename;
	var $enablePermissions;
	var $enableNewDir;
	var $replSpacesUpload;
	var $replSpacesDownload;
	var $lowerCaseUpload;
	var $lowerCaseDownload;
	var $createBackups;
	var $loginPassword;
	var $mailOnUpload;
	var $mailOnDownload;
	var $debugInfo;

	/**
	 * path to temporary directory
	 *
	 * @var string
	 */
	var $tmpDir;

	/**
	 * path to cache directory
	 *
	 * @var string
	 */
	var $cacheDir;

	/**
	 * HTML container name
	 *
	 * @var string
	 */
	var $container;

/* PRIVATE PROPERTIES ************************************************************************** */

	/**
	 * file manager directory path (for includes)
	 *
	 * @var string
	 */
	var $incPath;

	/**
	 * error messages
	 *
	 * @var string
	 */
	var $error;

	/**
	 * holds listing object
	 *
	 * @var Listing
	 */
	var $Listing;

	/**
	 * HTML container name
	 *
	 * @var string
	 */
	var $listCont;

	/**
	 * HTML container name
	 *
	 * @var string
	 */
	var $logCont;

	/**
	 * HTML container name
	 *
	 * @var string
	 */
	var $infoCont;

	/**
	 * user access
	 *
	 * @var boolean
	 */
	var $access;

/* PUBLIC METHODS ****************************************************************************** */

	/**
	 * constructor
	 *
	 * @param string $startDir		optional: directory path
	 * @return FileManager
	 */
	function FileManager($startDir = '') {
		$this->incPath = str_replace('\\', '/', realpath(dirname(__FILE__) . '/..'));
		$this->tmpDir = $this->incPath . '/tmp';
		$this->cacheDir = $this->incPath . '/cache';

		$this->initFromConfig();
		if($startDir != '') $this->startDir = $startDir;

		if($this->fmWebPath == '') {
			$this->fmWebPath = ereg_replace('^' . $_SERVER['DOCUMENT_ROOT'], '', $this->incPath);
			if($this->fmWebPath == $this->incPath) {
				$ld = Tools::basename($_SERVER['DOCUMENT_ROOT'], $this->encoding);
				$this->fmWebPath = substr($this->incPath, strpos($this->incPath, $ld) + strlen($ld));
			}
		}
	}

	/**
	 * initialization from config file
	 */
	function initFromConfig() {
		include($this->incPath . '/config.inc.php');
		$this->ftpHost = $ftpHost;
		$this->ftpUser = $ftpUser;
		$this->ftpPassword = $ftpPassword;
		$this->ftpPort = $ftpPort ? $ftpPort : 21;
		$this->ftpPassiveMode = $ftpPassiveMode;
		$this->language = $language;
		$this->encoding = $encoding;
		$this->locale = $locale;
		$this->startDir = $startDir;
		$this->startSubDirs = $startSubDirs;
		$this->startSearch = $startSearch;
		$this->fmWebPath = $fmWebPath;
		$this->fmWidth = $fmWidth;
		$this->fmHeight = $fmHeight;
		$this->fmMargin = $fmMargin;
		$this->fmView = $fmView;
		$this->logHeight = $logHeight;
		$this->explorerWidth = $explorerWidth;
		$this->thumbMaxWidth = $thumbMaxWidth;
		$this->thumbMaxHeight = $thumbMaxHeight;
		$this->defaultFilePermissions = $defaultFilePermissions;
		$this->defaultDirPermissions = $defaultDirPermissions;
		$this->allowFileTypes = $allowFileTypes;
		$this->hideFileTypes = $hideFileTypes;
		$this->hideSystemFiles = $hideSystemFiles;
		$this->hideSystemType = $hideSystemType;
		$this->hideFilePath = $hideFilePath;
		$this->hideLinkTarget = $hideLinkTarget;
		$this->hideDisabledIcons = $hideDisabledIcons;
		$this->enableUpload = $enableUpload;
		$this->enableDownload = $enableDownload;
		$this->enableEdit = $enableEdit;
		$this->enableDelete = $enableDelete;
		$this->enableRename = $enableRename;
		$this->enablePermissions = $enablePermissions;
		$this->enableNewDir = $enableNewDir;
		$this->replSpacesUpload = $replSpacesUpload;
		$this->replSpacesDownload = $replSpacesDownload;
		$this->lowerCaseUpload = $lowerCaseUpload;
		$this->lowerCaseDownload = $lowerCaseDownload;
		$this->createBackups = $createBackups;
		$this->loginPassword = $loginPassword;
		$this->mailOnUpload = $mailOnUpload;
		$this->mailOnDownload = $mailOnDownload;
		$this->debugInfo = $debugInfo;
	}

	/**
	 * create file manager
	 *
	 * @return string	HTML code
	 */
	function create() {
		global $fmCnt, $msg;

		ob_start();

		if(!$fmCnt) $fmCnt = 1;
		if($fmCnt == 1) {
			$this->getLanguageFile();
			$fmWebPath = $this->fmWebPath;
			$fmEncoding = $this->encoding;
			include_once($this->incPath . '/template.inc.php');
		}

		if($this->startDir != '') {
			if(!$this->ftpHost) $this->startDir = realpath($this->startDir);
			$this->startDir = str_replace('\\', '/', $this->startDir);

			if($this->ftpHost) {
				$this->startDir = preg_replace('%/*\.\.%', '', $this->startDir);
				$this->startDir = preg_replace('%^/+%', '', $this->startDir);
			}
		}

		if($this->ftpHost && $this->startDir == '') $this->startDir = '.';
		if($this->loginPassword == '') $this->access = true;

		$this->container = 'fmCont' . $fmCnt;
		$this->listCont = 'fmList' . $fmCnt;
		$this->logCont = 'fmLog' . $fmCnt;
		$this->infoCont = 'fmInfo' . $fmCnt;
		$this->save();

		$this->viewHeader();
		$this->viewFooter();

		$url = $this->fmWebPath . '/action.php?fmContainer=' . $this->container;
		$mode = ($this->startSearch != '') ? "search&fmName=$this->startSearch" : 'refresh';
		print "<script type=\"text/javascript\">\n";
		print "setTimeout(\"fmCall('$url&fmMode=$mode')\", 250);\n";
		print "</script>\n";
		$fmCnt++;

		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

	/**
	 * return listing object
	 *
	 * @return Listing
	 */
	function &getListing() {
		if(!$this->Listing) switch($this->fmView) {
			case 'details':	$this->Listing =& new ListingDetail($this); break;
			case 'icons':	$this->Listing =& new ListingIcon($this); break;
			default:		die('Invalid view type "' . $this->fmView . '"');
		}
		return $this->Listing;
	}

	/**
	 * get language file
	 */
	function getLanguageFile() {
		global $msg;

		if(!isset($this->language)) $this->language = 'en';
		$file = $this->incPath . '/languages/lang_' . $this->language . '.inc';
		$data = Tools::readLocalFile($file, $this->encoding);

		if(preg_match_all('/(\w+)\s*=\s*(.+)/', $data, $m)) {
			for($i = 0; $i < count($m[0]); $i++) {
				$key = trim($m[1][$i]);
				$val = trim($m[2][$i]);
				$msg[$key] = $val;
			}
		}
	}

	/**
	 * perform requested action
	 */
	function action() {
		global $msg;

		$fmMode = Tools::utf8Decode($_REQUEST['fmMode'], $this->encoding);
		$fmName = Tools::utf8Decode($_REQUEST['fmName'], $this->encoding);

		$this->getLanguageFile();

		if(!$this->ftpHost && $this->startDir == '') {
			die("SECURITY ALERT:<br/>Please set a start directory or an FTP server!");
		}
		else if($fmMode == 'login' && $fmName == $this->loginPassword) {
			$this->access = true;
			$fmMode = 'refresh';
		}
		else if($this->loginPassword != '' && !$this->access) {
			$this->viewLogin();
		}

		if(!$this->error && $this->access) {
			$fmObject = $_REQUEST['fmObject'];
			$fmPerms = $_REQUEST['fmPerms'];

			$this->getListing();

			switch($fmMode) {
				case 'sort':
					list($this->Listing->sortField, $this->Listing->sortOrder) = explode(',', $fmName);
					$this->Listing->view();
					break;

				case 'open':
					if($fmObject != '') {
						if($Entry =& $this->Listing->getEntry($fmObject)) {
							if($Entry->isDir()) {
								$this->Listing->prevDir = $this->Listing->curDir;
								$this->Listing->curDir = $Entry->path;
								$this->Listing->searchString = '';
								Tools::cleanDir($this->cacheDir);

								if(!$this->Listing->refresh()) {
									$this->error = $msg['errOpen'] . ": $Entry->name";
								}
							}
						}
					}
					break;

				case 'expOpen':
					if($fmObject != '') {
						if($entry = $this->Listing->Explorer->folders[$fmObject]) {
							$this->Listing->prevDir = $this->Listing->curDir;
							$this->Listing->curDir = $entry[1];
							$this->Listing->searchString = '';
							Tools::cleanDir($this->cacheDir);

							if(!$this->Listing->refresh()) {
								$this->error = $msg['errOpen'] . ': ' . Tools::basename($entry[1], $this->encoding);
							}
						}
					}
					break;

				case 'getFile':
					if($this->enableDownload && $fmObject != '') {
						if($Entry =& $this->Listing->getEntry($fmObject)) {
							if(!$Entry->sendFile()) {
								$this->error = $msg['errOpen'] . ": $Entry->name";
								$this->Listing->view();
							}
						}
					}
					break;

				case 'getThumbnail':
					if($fmObject != '') {
						if($Entry =& $this->Listing->getEntry($fmObject)) {
							$Image = new Image($Entry->getImagePath(), $_REQUEST['width'], $_REQUEST['height']);
							$Image->view();
						}
					}
					break;

				case 'parent':
					$this->Listing->prevDir = $this->Listing->curDir;
					$this->Listing->curDir = ereg_replace('/[^/]+$', '', $this->Listing->curDir);
					$this->Listing->searchString = '';
					Tools::cleanDir($this->cacheDir);
					$this->Listing->refresh();
					break;

				case 'rename':
					if($this->enableRename && $fmName != '' && $fmObject != '') {
						if($Entry =& $this->Listing->getEntry($fmObject)) {
							$path = Tools::dirname($Entry->path, $this->encoding);
							if(get_magic_quotes_gpc()) $fmName = stripslashes($fmName);
							$fmName = Tools::basename($fmName, $this->encoding);

							if(!$Entry->rename("$path/$fmName")) {
								$this->error = $msg['errRename'] . ": $Entry->name &raquo; $fmName";
							}
							else if($Entry->isDir()) {
								$this->Listing->Explorer = null;
							}
						}
					}
					if(!$this->error) $this->Listing->refresh();
					break;

				case 'delete':
					if($this->enableDelete && $fmObject != '') {
						$entries = explode(',', $fmObject);
						$errors = array();

						foreach($entries as $id) {
							if($Entry =& $this->Listing->getEntry($id)) {
								if($Entry->isDir()) {
									if(!$this->Listing->remDir($Entry->path)) {
										$errors[] = $msg['errDelete'] . ": $Entry->name";
									}
									else $this->Listing->Explorer = null;
								}
								else if(!$Entry->deleteFile()) {
									$errors[] = $msg['errDelete'] . ": $Entry->name";
								}
							}
						}
					}
					if(count($errors) > 0) $this->error .= join('<br/>', $errors);
					$this->Listing->refresh();
					break;

				case 'newDir':
					if($this->enableNewDir) {
						if($fmName != '') {
							if(get_magic_quotes_gpc()) $fmName = stripslashes($fmName);
							$fmName = str_replace('\\', '/', $fmName);
							$dirs = explode('/', $fmName);
							$dir = '';

							for($i = 0; $i < count($dirs); $i++) {
								if($dirs[$i] != '') {
									if($dir != '') $dir .= '/';
									$dir .= $dirs[$i];
									$curDir = $this->Listing->curDir;

									if(!$this->Listing->mkDir("$curDir/$dir")) {
										$this->error = $msg['errDirNew'] . ": $dir";
										break;
									}
									else {
										$this->Listing->Explorer = null;
										if($this->defaultDirPermissions) {
											$Entry =& $this->Listing->getEntryByName($dir);
											if(!$Entry || !$Entry->changePerms($this->defaultDirPermissions)) {
												$this->error = $msg['errPermChange'] . ": $dir";
												break;
											}
										}
									}
								}
							}
						}
					}
					$this->Listing->refresh();
					break;

				case 'newFile':
					if($this->enableUpload) {
						$fmFile = $_FILES['fmFile'];
						$fmReplSpaces = $_REQUEST['fmReplSpaces'];
						$fmLowerCase = $_REQUEST['fmLowerCase'];
						$uploaded = $errors = array();

						if(is_array($fmFile)) {
							for($i = 0; $i < count($fmFile['size']); $i++) {
								$newFile = $fmFile['name'][$i];

								if($fmFile['size'][$i]) {
									if($this->hideSystemFiles && $newFile[0] == '.') {
										$errors[] = $msg['errAccess'] . ": $newFile";
									}
									else {
										if($this->replSpacesUpload || $fmReplSpaces) {
											$newFile = str_replace(' ', '_', $newFile);
										}

										if($this->lowerCaseUpload || $fmLowerCase) {
											$newFile = strtolower($newFile);
										}

										if(!$this->Listing->upload($fmFile['tmp_name'][$i], $newFile)) {
											$errors[] = $msg['errSave'] . ": $newFile";
										}
										else {
											$uploaded[] = array(
												'path' => $this->Listing->curDir . '/' . $newFile,
												'size' => $fmFile['size'][$i]

											);
											if($this->defaultFilePermissions) {
												$Entry =& $this->Listing->getEntryByName($newFile);
												if(!$Entry || !$Entry->changePerms($this->defaultFilePermissions)) {
													$errors[] = $msg['errPermChange'] . ": $newFile";
												}
											}
										}
									}
								}
								else if($newFile != '') {
									$errors[] = $msg['error'] . ": $newFile = 0 B";
									$maxFileSize = ini_get('upload_max_filesize');
									$postMaxSize = ini_get('post_max_size');
									$info = "PHP settings: upload_max_filesize = $maxFileSize, ";
									$info .= "post_max_size = $postMaxSize";
									$error = "Could not upload $newFile ($info)";
									$this->Listing->FileSystem->addMsg($error, 'error');
								}
							}
						}
						$this->Listing->refresh();
						if(count($errors) > 0) $this->error .= join('<br/>', $errors);

						if($this->mailOnUpload && $uploaded) {
							$date = date('Y-m-d H:i:s');
							$ip = $_SERVER['REMOTE_ADDR'] ? $_SERVER['REMOTE_ADDR'] : 'n/a';
							$body = "The following files have been uploaded on $date by IP address $ip:\n\n";
							foreach($uploaded as $file) $body .= $file['path'] . ' ' . $file['size'] . " B\n";
							@mail($this->mailOnUpload, 'FileManager Upload Info', $body);
						}
					}
					else $this->Listing->view();
					break;

				case 'refresh':
					$this->Listing->Explorer = null;
					$this->Listing->refresh();
					break;

				case 'permissions':
					if($this->enablePermissions && is_array($fmPerms) && $fmObject != '') {
						if($Entry =& $this->Listing->getEntry($fmObject)) {
							$mode = '';
							for($i = 0; $i < 9; $i++) {
								$mode .= $fmPerms[$i] ? 1 : 0;
							}
							if(!$Entry->changePerms(bindec($mode))) {
								$this->error = $msg['errPermChange'] . ": $Entry->name";
							}
						}
					}
					if(!$this->error) $this->Listing->refresh();
					break;

				case 'edit':
					if($this->enableEdit && $fmObject != '') {
						if($Entry =& $this->Listing->getEntry($fmObject)) {
							$fmText = $_POST['fmText'];
							if($fmText != '') {
								if(!$Entry->saveFile($fmText)) {
									$this->error = $msg['errSave'] . ": $Entry->name";
								}
								else $this->Listing->refresh();
							}
							else {
								$Editor = new Editor($this);
								$Editor->view($Entry);
							}
						}
					}
					break;

				case 'search':
					$this->Listing->performSearch($fmName);
					break;

				case 'switchView':
					$this->Listing =& $this->Listing->switchView();
					$this->Listing->refresh();
					break;

				default: if(!$this->error) $this->Listing->view();
			}
			if($this->ftpHost) $this->Listing->FileSystem->ftpClose();
			Tools::cleanDir($this->tmpDir);
			$log = $this->Listing->FileSystem->getMessages();
		}

		if($this->error != '') {
			print '{{fmERROR}}' . $this->error . '{{/fmERROR}}';
			$this->error = '';
		}

		if($this->debugInfo) {
			print '{{fmINFO}}' . $this->getDebugInfo() . '{{/fmINFO}}';
		}
		print '{{fmLOG}}' . $log . '{{/fmLOG}}';
		$this->save();
	}

/* PRIVATE METHODS ***************************************************************************** */

	/**
	 * view header
	 */
	function viewHeader() {
		$listHeight = $this->fmHeight;
		if($this->logHeight > 0) $listHeight -= $this->logHeight + 9;
		if($this->debugInfo) $listHeight -= 151;

		print "<div id=\"$this->container\" class=\"fmTH1\" style=\"position:relative; padding:1px; ";
		print "width:{$this->fmWidth}px; margin:{$this->fmMargin}px\">\n";
		print "<div id=\"$this->listCont\" class=\"fmTH1\">\n";
		print "<div class=\"fmTH2\" style=\"width:{$this->fmWidth}px; height:{$listHeight}px\">&nbsp;</div>\n";
		print "</div>\n";
	}

	/**
	 * view footer
	 */
	function viewFooter() {
		if($this->logHeight > 0) {
			$width = $this->fmWidth - 8;
			print "<div id=\"$this->logCont\" class=\"fmTH2\" ";
			print "style=\"width:{$width}px; height:{$this->logHeight}px; ";
			print "margin-top:1px; padding:4px; text-align:left; overflow:auto\">\n";
			print "</div>\n";
		}

		if($this->debugInfo) {
			print "<div id=\"$this->infoCont\" class=\"fmTH2\" ";
			print "style=\"width:{$this->fmWidth}px; height:150px; ";
			print "margin-top:1px; text-align:left; overflow:auto\">\n";
			print "</div>\n";
		}
		print "</div>\n";
	}

	/**
	 * view login form
	 */
	function viewLogin() {
		global $msg;

		$url = $this->fmWebPath . '/action.php?fmContainer=' . $this->container;
		$action = "javascript:fmCall('$url', '{$this->container}Login')";
		$listHeight = $this->fmHeight - 22;
		if($this->logHeight > 0) $listHeight -= $this->logHeight + 9;
		if($this->debugInfo) $listHeight -= 151;

		print "<form name=\"{$this->container}Login\" action=\"$action\" class=\"fmForm\" method=\"post\">\n";
		print "<input type=\"hidden\" name=\"fmMode\" value=\"login\"/>\n";
		print "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><tr>\n";
		print "<td class=\"fmTH1\" style=\"padding:4px\" align=\"left\" nowrap=\"nowrap\">{$msg['cmdLogin']}</td>\n";
		print "</tr><tr>\n";
		print "<td class=\"fmTH3\" align=\"center\" style=\"height:{$listHeight}px; padding:4px\">\n";
		print "<input type=\"password\" name=\"fmName\" size=\"20\" maxlength=\"60\" class=\"fmField\"/><br/>\n";
		print "<input type=\"submit\" class=\"fmButton\" value=\"{$msg['cmdLogin']}\"/>\n";
		print "</td>\n";
		print "</tr></table>\n";
		print "</form>\n";
	}

	/**
	 * get debug info
	 */
	function getDebugInfo() {
		$html =  '<div class="fmTH1" style="padding:4px; text-align:left">DEBUG INFO</div>';
		$html .= '<div class="fmTD2" style="padding:2px; text-align:left">';
		$html .= '<table border="0" cellspacing="0" cellpadding="2">';
		$html .= '<tr valign="top"><td class="fmTD2">Cookie info:</td>';
		$html .= '<td class="fmTD2">' . nl2br(str_replace(' ', '&nbsp;', print_r(session_get_cookie_params(), true))) . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">FileManager::$language:</td><td class="fmTD2">' . $this->language . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">FileManager::$encoding:</td><td class="fmTD2">' . $this->encoding . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">FileManager::$locale:</td><td class="fmTD2">' . $this->locale . ' (system: ' . @setlocale(LC_ALL, '0') . ')</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">FileManager::$fmWebPath:</td><td class="fmTD2">' . $this->fmWebPath . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">FileManager::$startDir:</td><td class="fmTD2">' . $this->startDir . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">Listing::$curDir:</td><td class="fmTD2">' . $this->Listing->curDir . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">Listing::$prevDir:</td><td class="fmTD2">' . $this->Listing->prevDir . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">Listing::$searchString:</td><td class="fmTD2">' . $this->Listing->searchString . '</td>';
		$html .= '</tr><tr valign="top">';
		$html .= '<td class="fmTD2">Cache directory:</td><td class="fmTD2">' . Tools::getFileCount($this->cacheDir) . ' files</td>';
		$html .= '</tr></table>';
		$html .= "</div>\n";
		return $html;
	}

	/**
	 * save FileManager object
	 */
	function save() {
		$_SESSION[$this->container] = serialize($this);
	}
}

?>