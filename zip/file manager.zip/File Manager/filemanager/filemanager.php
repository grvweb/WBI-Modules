<?php

/**
 * +-------------------------------------------------------------------+
 * |                    F I L E M A N A G E R   (v6.5)                 |
 * |                                                                   |
 * | Copyright Gerd Tentler               www.gerd-tentler.de/tools    |
 * | Created: Dec. 7, 2006                Last modified: Mar. 13, 2010 |
 * +-------------------------------------------------------------------+
 * | This program may be used and hosted free of charge by anyone for  |
 * | personal purpose as long as this copyright notice remains intact. |
 * |                                                                   |
 * | Obtain permission before selling the code for this program or     |
 * | hosting this software on a commercial website or redistributing   |
 * | this software over the Internet or in any other medium. In all    |
 * | cases copyright must remain intact.                               |
 * +-------------------------------------------------------------------+
 */

include_once('class/FileManager.php');
$FileManager = new FileManager();
$parts = parse_url($FileManager->fmWebPath);
if(!$parts) die('ERROR: invalid web path!');

session_set_cookie_params(0, $parts['path'], $parts['host']);
session_start();

header("Content-type: text/html; charset=$FileManager->encoding");
header('Cache-control: private, no-cache, must-revalidate');
header('Expires: 0');

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>File Manager</title>
</head>
<body style="background-color:#F0F0F0">
<table border="0" width="100%" height="90%"><tr>
<td align="center">
<?php

print $FileManager->create();

?>
</td>
</tr></table>
</body>
</html>