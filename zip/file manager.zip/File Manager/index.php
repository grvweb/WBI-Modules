<?php include_once("modules/storage/File Manager/filemanager/class/FileManager.php"); ?>
<?php include("modules/storage/File Manager/modinfo.zp.php");?>







<br />
<?php

echo $welcomenote;

?>


<br />


<?php

$FileManager = new FileManager('c:/ZPanel/hostdata/' . $_SESSION['zUsername'] . '/');
print $FileManager->create();
?>
