<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
#     3) AGREE TO THE FOLLOWING DISCLAIMER...                                #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                 #
##############################################################################
include("config.php");
if ($overidehostname == 1){
	$address = $host;
	}else{
	$address = $_SERVER['HTTP_HOST'];
	}
include("ftpheader.php");	
if ($debug == 1) {echo'[<font color="blue">DEBUGGING ON</font> - Server IP: <font color="red">'.$address.'</font>]<br>';}
//echo 'FTP directory for user: <b>'.$_POST["username"].'</b><br>';
echo '<CENTER>
<!-- NOTE: All runtime properties are defined in params.txt by default -->
<object width="800" height="600" classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93" 
	codebase="http://java.sun.com/update/1.5.0/jinstall-1_5-windows-i586.cab#Version=1,5,0,0">
    <param name="code" value="com.jscape.ftpapplet.FtpApplet.class">
    <param name="archive" value="sftpapplet.jar">
    <param name="scriptable" value="false">
    <param name="hostname" value="'.$address.'">
    <param name="username" value="'.base64_encode ($_POST["username"]).'">
    <param name="password" value="'.base64_encode ($_POST["password"]).'">
    <param name="autoConnect" value="'.$autoConnect.'">
    <param name="showButtons" value="'.$showButtons.'">
    <param name="showHiddenFiles" value="'.$showHiddenFiles.'">
    <param name="enableAnonymous" value="'.$enableAnonymous.'">
    <param name="loginErrorUrl" value="'.$loginErrorUrl.'">
    <param name="encrypt" value="true">
    <param name="showMode" value="'.$showMode.'">
    <comment>
	<embed 
            type="application/x-java-applet;version=1.5" \
            code="com.jscape.ftpapplet.FtpApplet.class" \
            archive="sftpapplet.jar" \
            name="ftpapplet" \
            width="800" \
            height="600" \
		    scriptable="false" \
			hostname="'.$address.'" \
			username="'.base64_encode ($_POST["username"]).'" \
			username="'.base64_encode ($_POST["username"]).'" \
			password="'.base64_encode ($_POST["password"]).'" \
			autoConnect="'.$autoConnect.'" \
			showButtons="'.$showButtons.'" \
			showHiddenFiles="'.$showHiddenFiles.'" \
			enableAnonymous="'.$enableAnonymous.'" \
			loginErrorUrl="'.$loginErrorUrl.'" \
			encrypt="true" \
			showMode="'.$showMode.'" \
		    pluginspage = "http://java.sun.com/products/plugin/index.html#download">
		    <noembed>            
            </noembed>
	</embed>
    </comment>
</object>
</CENTER>';
include("ftpfooter.php");
?>
