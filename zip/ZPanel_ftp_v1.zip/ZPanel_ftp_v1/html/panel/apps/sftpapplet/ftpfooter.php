<br>
 <table cellpadding="5" cellspacing="0" width="100%" >
  <tr class="copypower">
    <td class="copypower">Copyright �
2004-2010 <a href="http://www.zpanel.co.uk/" target="_blank">ZPanel Project</a>.
<br></td>
  </tr>
</table>