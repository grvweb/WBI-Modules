<?php
$debug = 0; 					// enable debug to verify what ip is being passed to the ftp server
$overidehostname = 0;	 		// 0 = no, 1 = yes
$host = "0.0.0.0"; 				// set a static ip for the FTP client
$loginErrorUrl = ""; 
								//redirect a failed logon to a different web page

// OVERIDE CLIENT BEHAVIOR
//recommend that you leave these alone, but can change them if you need to

$enableAnonymous = "false"; 	// allow anonymous connections
$showHiddenFiles = "false"; 	//allow viewing of hidden files
$showButtons = "false"; 		//show or hide client connection buttons
$showMode = "false"; 			//show or hide the ASCII or BINARY mode buttons
$autoConnect = "true"; 			//enable or disable client auto connect
?>
