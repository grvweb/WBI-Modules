<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>


<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>ZPanel &gt; FTP Browser</title>
<link href="inc/4.css" rel="stylesheet" type="text/css">
</head><body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td background="inc/zp_gradient4.jpg" rowspan="2" align="left" valign="top"><img src="inc/zp_logo4.jpg" width="282" border="0" height="75"></td>
    <td background="inc/zp_gradient4.jpg" align="right" valign="top"><table class="topbarlinks" border="0" cellpadding="2" cellspacing="2">
      <tbody><tr>
        <td align="center" background="inc/zp_gradient4.jpg" width="400"><h2>FTP directory for user: <b><?php echo''.$_POST["username"].'' ?></b></h2></td>
        <td>
          </td>
      </tr>
    </tbody></table></td>
  </tr>
  <tr>
    <td></td>
  </tr>
</tbody></table>
<br />