<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
#     3) AGREE TO THE FOLLOWING DISCLAIMER...                                #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                 #
##############################################################################
include('conf/zcnf.php');
include('lang/' .GetSystemOption('zpanel_lang'). '.php');
include('inc/zAccountDetails.php');

echo "Secure FTP Applet is a JAVA based FTP client component that runs within your web browser. It is designed to let non-technical users exchange data secureiy with an FTP server.<br><br>Using Secure FTP Applet you can easily transfer multiple files and directories, delete files, rename files, create directories and so on all within your browser and without installing any software.<br><br>If you do not have JAVA installed, you will be prompted to install it automatically when you launch the FTP client";
echo "<br><br><br><br>";

//echo "&raquo; <a href=\"apps/sftpapplet/ftpindex.php\" target=\"_blank\" title=\"Launch FTP Browser\">Launch FTP Browser</a>";

echo '<form name="launchftp" method="post" action="apps/sftpapplet/ftpindex.php" target=ftpwindow> 
      <input type="hidden" name="username" value="'.$_SESSION['zUsername'].'" >
<b>For security reasons, please enter your FTP password for user:</b> '.$_SESSION['zUsername'].'<br><br>      
	  <input name="password"><br><br>
      <input type=submit value="Launch FTP"> 
      </form>

      <script>
      function sendme() 
      { 
         window.open("","ftpwindow","width=800,height=600,toolbar=0"); 
         var a = window.setTimeout("document.form1.submit();",500); 
      } 
      </script>';




?>
