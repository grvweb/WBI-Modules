<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
#     3) AGREE TO THE FOLLOWING DISCLAIMER...                                #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                 #
##############################################################################
include('conf/zcnf.php');
include('lang/' .GetSystemOption('zpanel_lang'). '.php');
include('inc/zAccountDetails.php');
ini_set('memory_limit', '128M');
$db = $_POST['database'];
$from_emailaddress = explode('@',$_POST['emailaddress']);
$from_emailaddress = $from_emailaddress[1]; 
$from_emailaddress = "MySQL_Backup@".$from_emailaddress."";
$to_emailaddress = $_POST['emailaddress'];
$time_internal=360;
error_reporting(0);
$newline="\r\n";
$limit_to=10000000; //total rows to export
$limit_from=0;

$sql = "SELECT * FROM z_mysql WHERE my_acc_fk=" .$useraccount['ac_id_pk']. " AND my_deleted_ts IS NULL";
$listmysql = DataExchange("r",$z_db_name,$sql);
$rowmysql = mysql_fetch_assoc($listmysql);
$totalmysql = DataExchange("t",$z_db_name,$sql);
$location = GetSystemOption('hosted_dir');
define('LOCATION', $location .$_SESSION['zUsername'].'/');

echo '<b>MySQL Database Backup.</b>  Backed up files will be compressed in .gz format.  If you need software to extract your backup file, try the free application <a href="http://www.7-zip.org/download.html" target="_blank">7zip</a>.';

if((isset($_POST['mysqlbackup']) && ($_POST['mysqlbackup']=='TRUE'))){
	if($_POST['database']==""){
	 echo "<br><br><div class=\"zannouce\">Database Not Backed up: NO DATABASE ENTERED</div>";
 	}
	if((isset($_POST['emailtrue'])) && $_POST['emailaddress']==""){
	echo "<br><br><div class=\"zannouce\">Database Not Backed up: NO EMAIL ENTERED</div>";
	}else{
	$cquery="SELECT * from ".$db.".phpmysqlautobackup WHERE id=1 LIMIT 1 ;";
	$cresult=mysql_query($cquery);
	$crow=mysql_fetch_array($cresult);
		if (time() < ($crow['time_last_run']+$time_internal)){
		$nextrun = (($crow['time_last_run']+$time_internal)-time());
		echo "<br><br><div class=\"zannouce\">CANNOT RUN BACKUP ON SAME DATABASE SO SOON: Please wait $nextrun seconds</div>";
		}else{
			if((isset($_POST['mysqlbackup'])) && ($_POST['mysqlbackup']=='TRUE') && (isset($_POST['emailtrue'])) && ($_POST['emailaddress']!="") || (isset($_POST['filetrue']))){
			echo "<br><br><div class=\"zannouce\">BACKUP SENT TO:"; 
				if (isset($_POST['emailtrue'])) { echo "&nbsp;&nbsp;Email: ".$_POST['emailaddress']."";}
				if (isset($_POST['filetrue'])) { echo "&nbsp;&nbsp;File Location: User Root/".$_SESSION['zUsername']."";}	
			echo "</div>";
			}else{
			echo "<br><br><div class=\"zannouce\">NO BACKUP SENT:  (Choose database and select \"Send to Email\" or \"Save to File\")</div>";
			}
		}
	}
}

//Begin HTML
if($totalmysql>0){
	?>
	<br /><br />
	<form name="mysqlbackup" method="post" action="<?php echo GetFullURL(); ?>">
  <table width="300px" class="zgrid">
    <tr>
		<td colspan="2"><br><h2>Select Database</h2></td>
	</tr>
    <tr>
    	<th>Database:</th>
		<td><select name="database">
		<?php do{ ?><option value="<?php echo Cleaner('o',$rowmysql['my_name_vc']); ?>"><?php echo Cleaner('o',$rowmysql['my_name_vc']); ?></option>
		<?php } while ($rowmysql = mysql_fetch_assoc($listmysql)); ?>
		</select>
		</td>
    </tr>
 	<tr>
    	<td colspan="2"> <h2>Email Options</h2></td>
	</tr>
    <tr>
    	<th>Send to Email:</th><td><input type="checkbox" name="emailtrue" value="1" /></td>
    </tr> 
    <tr>
    	<th>Email Address:</th><td><input type="text" name="emailaddress" value="<?php echo $_POST['emailaddress']; ?>" /></td>
    </tr>
    <tr>
		<td colspan="2"><br><h2>File Options</h2></td>
	</tr>
    <tr>
    	<th>Save to File:</th><td><input type="checkbox" name="filetrue" value="1" /></td>
    </tr>
    <tr>
    	<th>Saved in:</th><td>User Root: /<?php echo $_SESSION['zUsername']; ?></td>
    </tr>
    <tr>
    	<th><input type="submit" value="BACKUP" />
			<input type="hidden" name="mysqlbackup" value="TRUE" /></th><th></th>
    </tr>
  </table>
</form>
<?php
} else {
	echo $lang['132'];
}
echo "<br><br><b>Please DO NOT press BACKUP more than once.<br>You will be notified when backup is complete.</b>";
//START BACKUP
if((isset($_POST['mysqlbackup'])) && ($_POST['mysqlbackup']=='TRUE') && (isset($_POST['emailtrue'])) && ($_POST['emailaddress']!="") || (isset($_POST['filetrue']))){
$phpMySQLAutoBackup_version="1.5.4";
$backup_type="\n\n BACKUP Type: Full database backup (all tables included)\n\n";
//add new phpmysqlautobackup table if not there...
mysql_select_db($db);
if(mysql_num_rows(mysql_query("SHOW TABLES LIKE 'phpmysqlautobackup' "))==0)
{
   $query = "
    CREATE TABLE phpmysqlautobackup (
    id int(11) NOT NULL,
    version varchar(6) default NULL,
    time_last_run int(11) NOT NULL,
    PRIMARY KEY (id)
    ) TYPE=MyISAM;";
   $result=mysql_query($query);
   $query="INSERT INTO phpmysqlautobackup (id, version, time_last_run)
             VALUES ('1', '$phpMySQLAutoBackup_version', '0');";
   $result=mysql_query($query);
}
//check time last run - to prevent malicious over-load attempts
$query="SELECT * from phpmysqlautobackup WHERE id=1 LIMIT 1 ;";
$result=mysql_query($query);
$row=mysql_fetch_array($result);
if (time() < ($row['time_last_run']+$time_internal)){
}else{
//update version number if not already done so
if ($row['version']!=$phpMySQLAutoBackup_version) mysql_query("update phpmysqlautobackup set version='$phpMySQLAutoBackup_version'");

//BEGIN BACKING UP
if((isset($_POST['mysqlbackup'])) && ($_POST['mysqlbackup']=='TRUE') && (isset($_POST['emailtrue'])) && ($_POST['emailaddress']!="") || (isset($_POST['filetrue']))){
$query="UPDATE phpmysqlautobackup SET time_last_run = '".time()."' WHERE id=1 LIMIT 1 ;";
$result=mysql_query($query);
}

$t_query = mysql_query('show tables');
$i=0;
$table="";
	while ($tables = mysql_fetch_array($t_query, MYSQL_ASSOC) )
        {
         list(,$table) = each($tables);
         $exclude_this_table = isset($table_exclude)? in_array($table, $table_exclude) : false;
         if(!$exclude_this_table) $table_select[$i]=$table;
         $i++;
        }

$thedomain = $_SERVER['HTTP_HOST'];
if (substr($thedomain,0,4)=="www.") $thedomain=substr($thedomain,4,strlen($thedomain));

$buffer = '# MySQL backup created by phpMySQLAutoBackup - Version: '.$phpMySQLAutoBackup_version . "\n" .
          '# ' . "\n" .
          '# http://www.dwalker.co.uk/phpmysqlautobackup/' . "\n" .
          '#' . "\n" .
          '# Database: '. $db . "\n" .
          '# Domain name: ' . $thedomain . "\n" .
          '# (c)' . date('Y') . ' ' . $thedomain . "\n" .
          '#' . "\n" .
          '# Backup START time: ' . strftime("%H:%M:%S",time()) . "\n".
          '# Backup END time: #phpmysqlautobackup-endtime#' . "\n".
          '# Backup Date: ' . strftime("%d %b %Y",time()) . "\n";$i=0;
foreach ($table_select as $table)
        {
          $i++;
          $export = "\n" .'drop table if exists `' . $table . '`;' . "\n";

          //export the structure
          $query='SHOW CREATE TABLE `' . $table . '`';
          $rows_query = mysql_query($query);
          $tables = mysql_fetch_array($rows_query);
          $export.= $tables[1] ."; \n";

          $table_list = array();
          $fields_query = mysql_query('show fields from  `' . $table . '`');
          while ($fields = mysql_fetch_array($fields_query))
           {
            $table_list[] = $fields['Field'];
           }

          $buffer.=$export;
          // dump the data
          $query='select * from `' . $table . '` LIMIT '. $limit_from .', '. $limit_to.' ';
          $rows_query = mysql_query($query);
          while ($rows = mysql_fetch_array($rows_query)) {
            $export = 'insert into `' . $table . '` (`' . implode('`, `', $table_list) . '`) values (';
            reset($table_list);
            while (list(,$i) = each($table_list)) {
              if (!isset($rows[$i])) {
                $export .= 'NULL, ';
              } elseif (has_data($rows[$i])) {
                $row = addslashes($rows[$i]);
                $row = str_replace("\n#", "\n".'\#', $row);

                $export .= '\'' . $row . '\', ';
              } else {
                $export .= '\'\', ';
              }
            }
            $export = substr($export,0,-2) . "); \n";
            $buffer.= $export;
          }
        }
mysql_close();
$buffer = str_replace('#phpmysqlautobackup-endtime#', strftime("%H:%M:%S",time()), $buffer);

// zip the backup
$backup_file_name = 'mysql_'.$db.strftime("_%d_%b_%Y_time_%H_%M_%S.sql",time()).'.gz';
$dump_buffer = gzencode($buffer);

//email it
if ((isset($_POST['emailtrue'])) && ($_POST['emailtrue']=='1')){ 
xmail($to_emailaddress,$from_emailaddress, "phpMySQLAutoBackup: $backup_file_name", $dump_buffer, $backup_file_name, $backup_type, $newline, $phpMySQLAutoBackup_version);
}

//write it to file
if ((isset($_POST['filetrue'])) && ($_POST['filetrue']=='1')){
write_backup($dump_buffer, $backup_file_name);
}

//FTP backup file to remote server
if (isset($ftp_username))
{
 //write the backup file to local server ready for transfer if not already done so
 if (!$save_backup_zip_file_to_server) write_backup($dump_buffer, $backup_file_name);
 $transfer_backup = new transfer_backup();
 $transfer_backup->transfer_data($ftp_username,$ftp_password,$ftp_server,$ftp_path,$backup_file_name);
 if (!$save_backup_zip_file_to_server) unlink(LOCATION."../backups/".$backup_file_name);
}

}
}

//FUNCTIONS
function has_data($value)
{
 if (is_array($value)) return (sizeof($value) > 0)? true : false;
 else return (($value != '') && (strtolower($value) != 'null') && (strlen(trim($value)) > 0)) ? true : false;
}

function xmail ($to_emailaddress,$from_emailaddress, $subject, $content, $file_name, $backup_type, $newline, $ver)
{
 $mail_attached = "";
 $boundary = "----=_NextPart_000_01FB_010".md5($to_emailaddress);
 $mail_attached.="--".$boundary.$newline
                       ."Content-Type: application/octet-stream;$newline name=\"$file_name\"$newline"
                       ."Content-Transfer-Encoding: base64$newline"
                       ."Content-Disposition: attachment;$newline filename=\"$file_name\"$newline$newline"
                       .chunk_split(base64_encode($content)).$newline;
 $mail_attached .= "--".$boundary."--$newline";
 $add_header ="MIME-Version: 1.0".$newline."Content-Type: multipart/mixed;$newline boundary=\"$boundary\" $newline";
 $mail_content="--".$boundary.$newline."Content-Type: text/plain; $newline charset=\"iso-8859-1\"$newline"."Content-Transfer-Encoding: 7bit$newline $newline BACKUP Successful...$newline $newline Please see attached for your zipped Backup file; $backup_type $newline If this is the first backup then you should test it restores correctly to a test server.$newline $newline phpMySQLAutoBackup (version $ver) is developed by http://www.dwalker.co.uk/ $newline $newline Have a good day now you have a backup of your MySQL db  :-) $newline $newline Please consider making a donation at: $newline http://www.dwalker.co.uk/make_a_donation.php $newline (any amount is gratefully received)$newline".$mail_attached;
 return mail($to_emailaddress, $subject, $mail_content, "From: $from_emailaddress".$newline."Reply-To:$from_emailaddress".$newline.$add_header);
}

function write_backup($gzdata, $backup_file_name)
{
 $fp = fopen(LOCATION."/".$backup_file_name, "w");
 fwrite($fp, $gzdata);
 fclose($fp);
 //check folder is protected - stop HTTP access
 if (!file_exists(".htaccess"))
 {
  $fp = fopen(LOCATION, "w");
  fwrite($fp, "deny from all");
  fclose($fp);
 }
}
class transfer_backup
{
      function transfer_data($ftp_username,$ftp_password,$ftp_server,$ftp_path,$filename)
      {
       if (function_exists('curl_exec'))
       {
        $file=LOCATION."../backups/".$filename;
        $fp = fopen($file, "r");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "ftp://$ftp_username:$ftp_password@$ftp_server.$ftp_path".$filename);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_UPLOAD, 1);
        curl_setopt($ch, CURLOPT_INFILE, $fp);
        curl_setopt($ch, CURLOPT_INFILESIZE, filesize($file));
        curl_setopt($ch, CURLOPT_TRANSFERTEXT, 1);
        curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_HOST']." - via phpMySQLAutoBackup");
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        if (empty($info['http_code'])) die("ERROR - Failed to transfer backup file to remote ftp server");
        else
        {
         $http_codes = parse_ini_file(LOCATION."http_codes.ini");
         if ($info['http_code']!=226) echo "ERROR - server response: <br />".$info['http_code']
                                            ." " . $http_codes[$info['http_code']]."<br><br>"
                                            ."for more detail please refer to: http://www.w3.org/Protocols/rfc959/4_FileTransfer.html"                                            ;
        }
        curl_close($ch);
       }
      }
}
?>