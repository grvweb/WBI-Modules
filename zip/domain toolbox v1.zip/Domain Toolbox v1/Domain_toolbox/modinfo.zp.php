<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# ZPANEL MODULE CONFIGURATION FILE                                           #
##############################################################################

$thismod['title'] = 'Domain Toolbox';
$thismod['icon'] = 'icon.png';
$thismod['developer'] = 'Kerry Williams';
$thismod['developersite'] = 'http://www.hostraft.com/';
?>