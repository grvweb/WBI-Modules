# # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # #
Domain Toolbox v1 - By Kerry Williams
Ported for use within zpanel v5.0.2
Feel free to modify any code
But keep this copyright intact
Hostraft.com
# # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # #

Installation

You can install this module from zpanel v5 or higher.

How to install:

1. Navigate to your zpanel install

2. Go to the folder named "domains" which can be found within the following:

c:\zpanel\panel\modules\domains

3. Paste the folder called "Domain_toolbox" found in the .zip file into the "domains" folder.

4. Steps complete, please login to your zpanel and you should be able to find Domain Toolbox
under the Domains section.

For any support please post on the zpanel forums.

# # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # #