<h3>Domain Watcher</h3>
<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
#     3) AGREE TO THE FOLLOWING DISCLAIMER...                                #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                 #
##############################################################################
include('conf/zcnf.php');
include('inc/zAccountDetails.php');

$sql = "SELECT * FROM z_vhosts WHERE vh_deleted_ts IS NULL";
$listdomains = DataExchange("r",$z_db_name,$sql);
$rowdomains = mysql_fetch_assoc($listdomains);
$totaldomains = DataExchange("t",$z_db_name,$sql);

if($totaldomains>0){
?>
  <table class="zgrid">
    <tr>
	  <th>User Id</th>
	  <th>Username</th>
      <th>Domain / Subdomain</th>
      <th>Directory</th>
      <th>Status</th>
    </tr>
    <?php do{ ?>
    <tr>
      <td><?php echo Cleaner('o',$rowdomains['vh_acc_fk']); ?></td>
	  <td>
	  <?php 
	  $sql2 = "SELECT * FROM z_accounts WHERE ac_id_pk=" .$rowdomains['vh_acc_fk']. "";
	  $listusers = DataExchange("r",$z_db_name,$sql2);
      $rowusers = mysql_fetch_assoc($listusers);
	  echo Cleaner('o',$rowusers['ac_user_vc']);
	  ?>   
	  </td>
      <td><a href="http://<?php echo Cleaner('o',$rowdomains['vh_name_vc']); ?>" target="_blank">
	  <?php echo Cleaner('o',$rowdomains['vh_name_vc']); ?></a></td>
      <td><?php echo Cleaner('o',$rowusers['ac_user_vc']);?><?php echo Cleaner('o',$rowdomains['vh_directory_vc']); ?></td>
      <td><?php
      if($rowdomains['vh_active_in']==1){
		  echo "<font color=\"green\">Live</font>";
	  } else {
		  echo "<font color=\"orange\">Pending</font>";
	  }?></td>
    </tr>
    <?php } while ($rowdomains = mysql_fetch_assoc($listdomains)); ?>
  </table>
  
<?php
} ?>