<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# ZPANEL MODULE CONFIGURATION FILE                                           #
##############################################################################

$thismod['title'] = 'Password<br>Protect<br>Directories';
$thismod['icon'] = 'htpasswd.png';
$thismod['developer'] = 'RusTus (rustus@txt-clan.com';
$thismod['developersite'] = 'http://www.zpanel.co.uk/';
?>