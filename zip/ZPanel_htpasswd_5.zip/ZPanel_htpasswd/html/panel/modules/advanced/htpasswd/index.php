<script type="text/javascript" src="modules/advanced/htpasswd/browse.js"></script>

<?php
$sql = "SELECT * FROM z_mysql WHERE my_acc_fk=" .$useraccount['ac_id_pk']. " AND my_deleted_ts IS NULL";
$listmysql = DataExchange("r",$z_db_name,$sql);
$rowmysql = mysql_fetch_assoc($listmysql);
$path = GetSystemOption('hosted_dir').$_SESSION['zUsername']."/";
$userreturnpath = trim(substr($_POST['returnpath'], strlen(GetSystemOption('hosted_dir')), strlen($_POST['returnpath'])));
if (isset($_POST['deletehtaccess'])){deletehtaccess($useraccount['ac_id_pk'], $_POST['deletehtaccess'], $_POST['upatereturnpath']);}
if (isset($_POST['deleteuser'])){deleteuser($_POST['ht_id_pk'], $_POST['deleteuser']);}
if (isset($_POST['addhtaccess'])){addhtaccess($useraccount['ac_id_pk'], $_POST['ht_user_vc'], $_POST['ht_dir_vc'], $_POST['htusername'], $_POST['htpassword1'], $_POST['htpassword2'], $_POST['AuthName']);}
if (isset($_POST['adduser'])){adduser($useraccount['ac_id_pk'], $_POST['ht_user_vc'], $_POST['ht_dir_vc'], $_POST['htusername'], $_POST['htpassword1'], $_POST['htpassword2']);}

?>

<head>
	<style type="text/css">
		.hidden {display: none;}
		.show{color: #cccccc;}
	</style>
</head>
  
<body onLoad="browse('open','<?php echo "$path" ?>');">
  
<?php
if (isset($_POST['returnpath'])){
echo '<div class="zannouce"><b>SELECTED FOLDER: </b>'.$userreturnpath.'</div><br>';
}
?>
 
<table align="left" width="100%" cellpadding="5" cellspacing="0">
 <tr align="left" valign="top">
	<td class="statsdata" align="left">
  	<div style="width:250px" id="busy" align="left"></div><br>
  	<div align="left">
 	<b><span id="<?php echo "$path" ?>" title="open" onClick="browse(this.title,this.id);"></span></b>
	<span id="<?php echo "$path" ?>Info"></span>
  	</div>
	</td>
	<td width="100%">
	
<?php
//UPDATE
if (isset($_POST['upatehtaccess'])){
	$result = mysql_query("SELECT * FROM `z_htaccess` WHERE `ht_id_pk`='".$_POST['upatehtaccess']."'");
	$row = mysql_fetch_assoc($result);
		if (!empty($row['ht_dir_vc'])){
		echo'<h2>UPDATE .htaccess in Selected Directory</h2>
			 <table class="zgrid" width="100%" cellpadding="5"><tr><th>User</th><th>Encryted Password</th><th>Delete</th></tr>';
			$file=GetSystemOption('zpanel_root')."modules/advanced/htpasswd/files/".$_POST['upatehtaccess'].".htpasswd";
			$lines=file($file);
			foreach($lines as $line_num => $line){
			$data = explode(":", $line);
			echo'<tr><td width="10%">'.$data[0].'</td><td>'.$data[1].'</td><td align="center"><a href="javascript:void(0)" onClick="document.deleteuser.deleteuser.value=\''.$data[0].'\'; document.deleteuser.submit();"><img src="modules/advanced/htpasswd/images/delete.png" border="0"/></a></td></tr>';
			}
			 
			 
			 
		echo'</table>';
		echo'
			 <FORM id="adduser" action="'.GetFullURL().'" method="POST" name="adduser">
			 <INPUT type="hidden" name="adduser">
			 <INPUT type="hidden" name="ht_acc_fk" value="'.$useraccount['ac_id_pk'].'">
			 <INPUT type="hidden" name="ht_dir_vc" value="'.$_POST['returnpath'].'">
			 <INPUT type="hidden" name="ht_user_vc" value="'.$_SESSION['zUsername'].'">
			 <h2>Add New User</h2>
			 <table class="zgrid">
			 <tr><th>Username:</th><td><input type="text" name="htusername"></td></tr>
			 <tr><th>Password:</th><td><input type="password" name="htpassword1"></td></tr>
			 <tr><th>Confirm PW:</th><td><input type="password" name="htpassword2"></td></tr>
			 <tr><th></th><td align="right"><input type="submit" value="Add User"></td></tr>
			 </table>
			 </form>';
		}
}

//MAIN DISPLAY 
if (!isset($_POST['returnpath']) && !isset($_POST['upatehtaccess'])){
echo '<h2>Protect your directories with generated .htaccess files.</h2>
      To add entries, first select the directory you want to protect.<br><br>
	  1. Click the <b>folder</b> icon to expand the directory tree<br><br>2. Click on the <b>directory link</b> to select the directory for protection.';
	  	
		//INSTALL DATABASE IF NOT FOUND
	  	if(mysql_num_rows(mysql_query("SHOW TABLES LIKE 'z_htaccess'"))==0){
			if (isset($_POST['updatemysql'])){
   			$query = "
			CREATE TABLE IF NOT EXISTS `z_htaccess` (
  			`ht_id_pk` int(11) unsigned NOT NULL AUTO_INCREMENT,
  			`ht_acc_fk` int(6) DEFAULT NULL,
  			`ht_user_vc` varchar(10) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  			`ht_dir_vc` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  			 PRIMARY KEY (`ht_id_pk`)
		 	) ENGINE=MyISAM  AUTO_INCREMENT=1";
   			$result=mysql_query($query);
   			$result=mysql_query("INSERT INTO `z_settings` (`st_name_vc`, `st_value_tx`, `st_desc_tx`, `st_label_vc`, `st_inputtype_vc`, `st_checkvalue_tx`, `st_editable_in`) VALUES ('htpasswd_exe', 'C:/ZPanel/bin/apache/bin/htpasswd.exe', 'Path to htpasswd.exe for potecting directories with .htaccess', NULL, 'text', NULL, NULL)");
			echo '<br><div class="zannouce"><b>MySQL DATABASE UPDATED: </b><a href="'.GetFullURL().'">Start Using Password Protect Directories</a></div><br>';
			}else{
			echo '
			<FORM action="'.GetFullURL().'" method="POST" name="updatemysql">
			<BR><BR><div class="zannouce"><center><b>**WARNING: MySQL DATABASE NOT UPDATED FOR THIS MODULE**</b></center></div>
			<div class="zannouce"><center>Press install to update your database for the first time<br><br>
			<input type="hidden" name="updatemysql">
			<input type="submit" value="INSTALL"></center>
			</form>
			</div>';
			}
			
		}
}

//EDIT DIRECTORY
if (isset($_POST['returnpath']) && !isset($_POST['upatehtaccess'])){
	$result = mysql_query("SELECT * FROM `z_htaccess` WHERE `ht_user_vc`='".$_SESSION['zUsername']."' AND `ht_dir_vc`='".$_POST['returnpath']."'");
	$row = mysql_fetch_assoc($result);
		if (!empty($row['ht_dir_vc'])){
		echo'<h2>Found .htaccess in Selected Directory</h2>
			 <table class="zgrid" width="100%" cellpadding="5"><tr><th>Directory</th><th>Edit</th><th>Delete</th></tr>
			 <tr><td width="100%">'.trim(substr($row['ht_dir_vc'], strlen(GetSystemOption('hosted_dir')), strlen($row['ht_dir_vc']))).'</td><td align="center"><a href="javascript:void(0)" onClick="document.upatehtaccess.upatehtaccess.value=\''.$row['ht_id_pk'].'\'; document.upatehtaccess.submit();"><img src="modules/advanced/htpasswd/images/edit.gif" border="0"/></a></td><td align="center"><a href="javascript:void(0)" onClick="document.deletehtaccess.deletehtaccess.value=\''.$row['ht_id_pk'].'\'; document.deletehtaccess.submit();"><img src="modules/advanced/htpasswd/images/delete.png" border="0"/></a></td></tr>
			 </table>';
		}else{
//ADD USERS
		echo'
			 <FORM id="addhtaccess" action="'.GetFullURL().'" method="POST" name="addhtaccess">
			 <INPUT type="hidden" name="addhtaccess">
			 <INPUT type="hidden" name="ht_acc_fk">
			 <INPUT type="hidden" name="ht_dir_vc" value="'.$_POST['returnpath'].'">
			 <INPUT type="hidden" name="ht_user_vc" value="'.$_SESSION['zUsername'].'">
			 <h2>Create .htaccess in Selected Directory</h2>
			 <table class="zgrid">
			 <tr><th>Message:</th><td><input type="text" name="AuthName" value="Restricted Area"></td></tr>
			 <tr><th>Username:</th><td><input type="text" name="htusername"></td></tr>
			 <tr><th>Password:</th><td><input type="password" name="htpassword1"></td></tr>
			 <tr><th>Confirm PW:</th><td><input type="password" name="htpassword2"></td></tr>
			 <tr><th></th><td align="right"><input type="submit" value="Create .htpasswd"></td></tr>
			 </table>
			 </form>';
		}
}

//GET ALL .HTACCESS DIRECTORIES
echo'<br><br><br><br><hr>';
getallhtaccess($_SESSION['zUsername']);

?>
	</td>
  </tr>
</table>

<FORM id="deletehtaccess" action="<?php echo GetFullURL(); ?>" method="POST" name="deletehtaccess">
<INPUT type="hidden" name="upatereturnpath" value="<?php echo $row['ht_dir_vc']; ?>">
<INPUT type="hidden" name="deletehtaccess">
</form>

<FORM id="upatehtaccess" action="<?php echo GetFullURL(); ?>" method="POST" name="upatehtaccess">
<INPUT type="hidden" name="upatereturnpath" value="<?php echo $row['ht_dir_vc']; ?>">
<INPUT type="hidden" name="returnpath" value="<?php echo $_POST['returnpath']; ?>">
<INPUT type="hidden" name="upatehtaccess">
</form>

<FORM id="deleteuser" action="<?php echo GetFullURL(); ?>" method="POST" name="deleteuser">
<INPUT type="hidden" name="ht_id_pk" value="<?php echo $_POST['upatehtaccess']; ?>">
<INPUT type="hidden" name="deleteuser">
</form>

<FORM id="getpath" action="<?php echo GetFullURL(); ?>" method="POST" name="getpath">
<INPUT type="hidden" name="returnpath"> 
</form>

  </body>
</html>

<?php 
//****************SCRIPT FUNCTIONS****************//

//GET ALL DIRECTORIES WITH .HTACCESS
function getallhtaccess($zUsername){
$result = mysql_query("SELECT * FROM `z_htaccess` WHERE `ht_user_vc`='".$zUsername."'");
$count =  mysql_num_rows($result);
	if ( $count>0){
		echo'<h2>All Directories with .htaccess files</h2>
		<table class="zgrid" width="100%" cellpadding="5"><tr><th>Directory</th><th>Select</th></tr>';
			while ($row = mysql_fetch_assoc($result)){
			echo "<tr><td width=\"100%\">".trim(substr($row['ht_dir_vc'], strlen(GetSystemOption('hosted_dir')), strlen($row['ht_dir_vc'])))."</td><td align=\"center\"><a href=\"javascript:void(0)\" onClick=\"document.getpath.returnpath.value='".$row['ht_dir_vc']."'; document.getpath.submit();\"><img src=\"modules/advanced/htpasswd/images/select.png\" border=\"0\"/></a></td></tr>";
			}
		echo'</table>';
	}
}

//ADD .HTACCESS
function addhtaccess($ht_acc_fk, $ht_user_vc, $ht_dir_vc, $htusername, $htpassword1, $htpassword2, $AuthName){
	if (!empty($htpassword1) && !empty($htpassword2) && ($htpassword1 == $htpassword2)){
	$result = mysql_query("INSERT INTO `z_htaccess` (`ht_acc_fk`, `ht_user_vc`, `ht_dir_vc`) VALUES ('$ht_acc_fk', '$ht_user_vc', '$ht_dir_vc')");
	$result = mysql_query("SELECT * FROM `z_htaccess` WHERE `ht_acc_fk` ='".$ht_acc_fk."' ORDER BY `ht_id_pk` DESC LIMIT 1");
	$row = mysql_fetch_assoc($result);
	system(GetSystemOption('htpasswd_exe')." -b -m -c ".GetSystemOption('zpanel_root')."/modules/advanced/htpasswd/files/".$row['ht_id_pk'].".htpasswd ".$htusername." ".$htpassword1."");
	$htaccessfile = $ht_dir_vc."/.htaccess";
	$fh = fopen($htaccessfile, 'w') or die('<div class="zannouce"><b>ERROR:</b> Can\'t open directory for writing</div><br>');
	$stringData = "AuthUserFile ".GetSystemOption('zpanel_root')."modules/advanced/htpasswd/files/".$row['ht_id_pk'].".htpasswd\r\nAuthType Basic\r\nAuthName \"".$AuthName."\"\r\nRequire valid-user";
	fwrite($fh, $stringData);

	fclose($fh);

	echo '<div class="zannouce"><b>CREATED HTACCESS ENTRY IN DIRECTORY:</b> '.trim(substr($ht_dir_vc, strlen(GetSystemOption('hosted_dir')), strlen($ht_dir_vc))).'</div><br>';
	}else{
	echo '<div class="zannouce"><b>ERROR:</b> Passwords do not match!</div><br>';
	}
}

//DELETE .HTACCESS
function deletehtaccess($useraccount, $ht_id_pk, $upatereturnpath){
$result = mysql_query("DELETE FROM `z_htaccess` WHERE `ht_acc_fk`='".$useraccount."' AND `ht_id_pk`='".$ht_id_pk."'");
unlink(GetSystemOption('zpanel_root')."modules/advanced/htpasswd/files/".$ht_id_pk.".htpasswd");
unlink($upatereturnpath."/.htaccess");
echo '<div class="zannouce"><b>DELETED HTACCESS ENTRY:</b> '.$ht_id_pk.'.htpasswd <b>FROM:</b> '.trim(substr($upatereturnpath, strlen(GetSystemOption('hosted_dir')), strlen($upatereturnpath))).'</div><br>';
}

//DELETE USER
function deleteuser($ht_id_pk, $user){
system(GetSystemOption('htpasswd_exe')." -D ".GetSystemOption('zpanel_root')."/modules/advanced/htpasswd/files/".$ht_id_pk.".htpasswd ".$user."");
echo '<div class="zannouce"><b>DELETED USER:</b> '.$user.' <b>FROM HTPASSWD ENTRY</b> '.$ht_id_pk.'.htpasswd</div><br>';
}

//ADD USER
function adduser($ht_acc_fk, $ht_user_vc, $ht_dir_vc, $htusername, $htpassword1, $htpassword2){
	if (!empty($htpassword1) && !empty($htpassword2) && ($htpassword1 == $htpassword2)){
	$result = mysql_query("SELECT * FROM `z_htaccess` WHERE `ht_acc_fk` ='".$ht_acc_fk."' AND `ht_dir_vc` = '".$ht_dir_vc."'");
	$row = mysql_fetch_assoc($result);
	system(GetSystemOption('htpasswd_exe')." -b -m ".GetSystemOption('zpanel_root')."/modules/advanced/htpasswd/files/".$row['ht_id_pk'].".htpasswd ".$htusername." ".$htpassword1."");
	echo '<div class="zannouce"><b>ADDED USER FOR DIRECTORY:</b> '.trim(substr($ht_dir_vc, strlen(GetSystemOption('hosted_dir')), strlen($ht_dir_vc))).'</div><br>';
	}else{
	echo '<div class="zannouce"><b>ERROR:</b> Passwords do not match!</div><br>';
	}
}
?>