Password Protect Directories

1. Install contents of html directory into your ZPanel root.

2. You will be prompted to update mysql tables if ran for the first time.

3. Use and enjoy!