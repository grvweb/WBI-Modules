-- phpMyAdmin SQL Dump
-- version 3.1.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 19, 2010 at 12:17 AM
-- Server version: 5.1.37
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zpanel_core`
--

-- --------------------------------------------------------

--
-- Table structure for table `z_htaccess`
--

CREATE TABLE IF NOT EXISTS `z_htaccess` (
  `ht_id_pk` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ht_acc_fk` int(6) DEFAULT NULL,
  `ht_user_vc` varchar(10) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `ht_dir_vc` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`ht_id_pk`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=91 ;

INSERT INTO `z_settings` (`st_name_vc`, `st_value_tx`, `st_desc_tx`, `st_label_vc`, `st_inputtype_vc`, `st_checkvalue_tx`, `st_editable_in`) VALUES
('htpasswd_exe', 'C:/ZPanel/bin/apache/bin/htpasswd.exe', 'Path to htpasswd.exe for potecting directories with .htaccess', NULL, 'text', NULL, NULL);
