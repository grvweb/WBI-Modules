<?php
$file = ("C:/Zpanel/bin/bind/zones/") . $_POST['name'] . ".txt";
$header = "$" . "TTL 10800\r\n";
$soa = "@     IN     SOA    " . $_POST['soa'] . ".     ";
$ADMIN_EMAIL = $_POST['ADMIN_EMAIL'] . ". (\r\n";
$serial = "                    2001062501 ; serial\r\n";
$refresh = "                    21600      ; refresh after 6 hours\r\n";
$retry = "                    3600       ; retry after 1 hour\r\n";
$expire = "                    604800     ; expire after 1 week\r\n";
$TTL = "                    86400 )    ; minimum TTL of 1 day\r\n";
$nameserver1 = "      IN     NS     "  . $_POST['ns1'] . ".\r\n";
$nameserver2 = "      IN     NS     "  . $_POST['ns2'] . ".\r\n";
$mailserver = "      IN     MX     10     " . $_POST['mx'] . ".\r\n";
$anyname = "@             IN     A       " . $_SERVER['REMOTE_ADDR'] . "\r\n" . "@             IN     A       " . $_SERVER['REMOTE_ADDR'] . "\r\n";
$ns1ip = "NS1         IN     A       " . $_SERVER['REMOTE_ADDR'] . "\r\n";
$ns2ip = "NS2         IN     A       " . $_SERVER['REMOTE_ADDR'] . "\r\n";
$ftp = "ftp          IN     CNAME   " . $_POST['name'] . ".\r\n";
$mail = "mail          IN     CNAME   " . $_POST['name'] . ".\r\n";
$www = "www          IN     CNAME   " . $_POST['name'] . ".\r\n";
$body = $header . $soa . $ADMIN_EMAIL . $serial . $refresh . $retry . $expire . $TTL . $nameserver1 . $nameserver2 . $mailserver . $anyname . $ns1ip . $ns2ip . $ftp . $mail . $www;
$fp = fopen($file,'w');
fwrite($fp,$body);
fclose($fp);
?>
<?php
$named = ("C:Zpanel/bin/bind/etc/") . "named.conf";
$body = "\r\n" . 'zone "' . $_POST['name'] . '" IN {' . "\r\n" . ' 	type master;' . "\r\n" . '	file "' . $_POST['name'] . ".txt" . '";' . "\r\n" . '	allow-transfer { none; };' . "\r\n" . "};";
$fp1 = fopen($named,'a');
fwrite ($fp1,$body);
fclose($fp1);
?>
<?php
popen ('"C:/Zpanel/bin/bind/bin/rndc reload"','r');
?>