<h2>Add Domains</h2>
<form name="form1" method="post" action="modules/admin/BIND-DNS-Management/createrecord.php">
  <table width="" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><label>Domain:</label></td>
      <td><label>
        <input type="text" name="name" id="name">
      </label></td>
    </tr>
    <tr>
      <td><label>SOA:</label></td>
      <td><label>
        <input type="text" name="soa" id="soa">
      </label></td>
    </tr>
    <tr>
      <td>Admin Email:</td>
      <td><label>
        <input type="text" name="ADMIN_EMAIL" id="ADMIN_EMAIL">
      </label></td>
    </tr>
    <tr>
      <td>NS1:</td>
      <td><label>
        <input type="text" name="ns1" id="ns1">
      </label></td>
    </tr>
    <tr>
      <td>NS2:</td>
      <td><label>
        <input type="text" name="ns2" id="ns2">
      </label></td>
    </tr>
    <tr>
      <td>MX:</td>
      <td><label>
        <input type="text" name="mx" id="mx">
      </label></td>
    </tr>
    <tr>
      <td>FTP:</td>
      <td><label>
        <input type="text" name="ftp" id="ftp">
      </label></td>
    </tr>
    <tr>
      <td>Mail:</td>
      <td><label>
        <input type="text" name="mail" id="mail">
      </label></td>
    </tr>
    <tr>
      <td>www:</td>
      <td><label>
        <input type="text" name="www" id="www">
      </label></td>
    </tr>
  </table>
  <br>
  <label>
    <input type="submit" name="addrecord" id="addrecord" value="Add">
  </label>
</form>
<h2>Edit Domains</h2>
<form name="editdomains" action="modules/admin/BIND-DNS-Management/editrecord.php">
<table border="0" cellpadding="0" cellspacing="0"><tr><td><label>Domain:</label></td><td><select name="name" id="name">
<?php
$dirpath = "C:/Zpanel/bin/bind/zones/";
$dh = opendir($dirpath);
while (false !== ($file = readdir($dh))) {
if (!is_dir("$dirpath/$file")) {
echo "<option id='name' value='$file'>" . htmlspecialchars(preg_replace('/\.txt*$/', '', $file)) . '</option>';
}
}
closedir($dh);
?></select></td></tr>
<tr><td><label>SOA:</label></td><td><input id="soa" name="soa" /></td></tr>
<tr><td><label>Admin Email:</label></td><td><input id="ADMIN_EMAIL" name="ADMIN_EMAIL" /></td></tr>
<tr>
  <td>NS1:</td>
  <td><label>
    <input type="text" name="ns1" id="ns1">
  </label></td>
</tr>
<tr>
  <td>NS2:</td>
  <td><label>
    <input type="text" name="ns2" id="ns2">
  </label></td>
</tr>
<tr>
  <td>MX:</td>
  <td><label>
    <input type="text" name="mx" id="mx">
  </label></td>
</tr>
<tr>
  <td>FTP:</td>
  <td><label>
    <input type="text" name="ftp" id="ftp">
  </label></td>
</tr>
<tr>
  <td>Mail:</td>
  <td><label>
    <input type="text" name="mail" id="mail">
  </label></td>
</tr>
<tr>
  <td>www:</td>
  <td><label>
    <input type="text" name="www" id="www">
  </label></td>
</tr>
</table>
<br>
<label>
  <input type="submit" name="edit" id="edit" value="Update">
</label>
</form>
<h2>Delete Domains</h2>
<form id="deldomains" name="deldomains" action="modules/admin/BIND-DNS-Management/deleterecord.php">
<table><tr><td><label>Domains:</label></td><td><label>
  <select name="name" size="1" id="name"><?php
$dirpath = "C:/Zpanel/bin/bind/zones/";
$dh = opendir($dirpath);
while (false !== ($file = readdir($dh))) {
if (!is_dir("$dirpath/$file")) {
echo "<option value='$file'>" . htmlspecialchars(preg_replace('/\.txt*$/', '', $file)) . '</option>';
}
}
closedir($dh);
?>
  </select>
</label></td></tr></table>
<br>
<label>
  <input type="submit" name="deldomain" id="deldomain" value="Delete">
</label>
</form>