<?php
$thismod['title'] = 'BIND DNS Management';
$thismod['icon'] = 'icon.gif';
$thismod['developer'] = 'Junious Norris (jj_norris@yahoo.com)';
$thismod['developersite'] = 'http://www.internet-hosting-solutions.net/';
?>