<?php
$file = ("C:/Zpanel/bin/bind/zones/") . $_GET['name'];
unlink($file);
?>
<?php
popen ('"C:/Zpanel/bin/bind/bin/rndc reload"','r');
?>