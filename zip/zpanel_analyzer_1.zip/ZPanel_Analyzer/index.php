<?php

##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
# 																			 #
# YOU MUST AGREE TO THE FOLLOWING DISCLAIMER...                          	 #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.	                             #
# 																			 #
##############################################################################
# 																			 #
# This ZPanel Analyzer is written by Marco (Cootje) and Patrick (Aaxklonp).	 #
# All copyright goes to Marco and Patrick.									 #
# 																			 #
# If you have questions about installing or using this script, you can		 #
# always mail us: zpanel@pdkwebs.nl. NO SPAM please.						 #
# 																			 #
# Best regards, have fun with your hosting,									 #
# 																			 #
# Marco (Cootje) and Patrick (Aaxklonp).									 #
##############################################################################

session_start();
if(!session_is_registered(myusername)){
header("location:login.php");
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

<link rel="stylesheet" href="style.css" type="text/css">
</head>
<?php
require "config.php";
$db_host = $database_host;
$db_user = $database_user;
$db_pwd = $database_password;
$database = 'zpanel_core';
if (!mysql_connect($db_host, $db_user, $db_pwd))
    die("Can't connect to database");
if (!mysql_select_db($database))
    die("Can't select database");
	?>
<script language="Javascript"> 
<!-- 
if (document.images) 
{
image1 = new Image 
image2 = new Image 
image1.src = 'images/return.png'
image2.src = 'images/return_over.png' 
} 
--> 
</script> 
</head>
<body  bgcolor="#FFFFFF" leftMargin="0" rightMargin="0" topMargin="0" bottomMargin="0">
<table height="100%" width="100%" cellpadding="0" cellspacing="0">
<tr>
<td align="center">
<table height="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td height="100%" width=31 background="images/left_shadow.gif" valign="bottom">
			<img src="images/left_shadow.gif">
		</td>
		<td  valign="top">
			<table width="100%" height="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td height="120" align="left">
					<img src="images/header.jpg" height="120" width="800"></td>
				</tr>
				<tr>
					<td height="100%" valign="top" background="images/inner_bg.gif">
						<table width="100%" height="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="202" valign="top" height="1">
									<table width="100%" height="100%" cellpadding="0" cellspacing="0" class="main">
									<tr><td class="mainlayout" valign="top" style="padding-bottom: 0px;">
									<br /><img src="images/menu.jpg">
								<table cellSpacing="0" cellPadding="4" width="100%">
									<tbody>
										<tr>
											<td align="left">
											<table border="0" cellSpacing="0" cellPadding="0" width="100%">
													<tr>
														<td>
<ul id="nav"> 
  <li><a href="index.php">Home</a></li> 
</ul>
<ul id="nav"> 
  <li><a href="logout.php">Log out</a></li> 
</ul>
 <br /><br />
<?php
$result1 = mysql_query("SELECT ac_user_vc AS '<b>Username</b>' FROM z_accounts WHERE ac_user_vc != 'tasksys' ORDER BY ac_user_vc");
if (!$result1) {
    die("Query to show fields from table failed");
}
$fields_num1 = mysql_num_fields($result1);
echo "";
for($i1=0; $i1<$fields_num1; $i1++)
{
    $field1 = mysql_fetch_field($result1);
    echo "";
}
echo "";
while($row1 = mysql_fetch_row($result1))
{
    echo "";
    foreach($row1 as $cell1)
        echo "<script type=\"text/javascript\">
startList = function() {
if (document.all&&document.getElementById) {
navRoot = document.getElementById(\"nav\");
for (i=0; i<navRoot.childNodes.length; i++) {
node = navRoot.childNodes[i];
if (node.nodeName==\"LI\") {
node.onmouseover=function() {
this.className+=\" over\";
  }
  node.onmouseout=function() {
  this.className=this.className.replace(\" over\", \"\");
   }
   }
  }
 }
}
window.onload=startList;
</script>
</head>
<body> 
<ul id=\"nav\"> 
  <li><a href=\"?p=details&username=$cell1\">$cell1</a> 
    <ul> 
	<li id=\"test\"><a href='?p=details&username=$cell1'>Details</a></li>
    <li id=\"test\"><a href='?p=domain&username=$cell1'>Domains</a></li>
	<li id=\"test\"><a href='?p=usage&username=$cell1'>Bandwidth/Diskspace</a></li>
	<li id=\"test\"><a href='?p=mysql&username=$cell1'>MySQL Databases</a></li>
	<li id=\"test\"><a href='?p=ftpaccs&username=$cell1'>FTP Accounts</a></li>
    </ul> 
  </li> 
</ul> 
";
}
mysql_free_result($result1);
?>
														</td>
													</tr>
													</table>
											</td>
										</tr>
								</table>
									</td></tr>				
									</table>
								</td>
								<td style="background: #FFFFFF; " vAlign="top" align="left">
								<p align="left">
</div>
<?php
$page = $_GET['p'];
$user = $_GET['username'];
if ($page=='') include 'home.php';
if ($page=='details') include 'details.php';
if ($page=='domain') include 'domain.php';
if ($page=='ftpaccs') include 'ftpaccs.php';
if ($page=='mysql') include 'mysql.php';
if ($page=='usage') include 'usage.php';
?>
</td>
							</tr>
						</table>
</td>
				</tr>
				<tr>
					<td height="50 align="center valign="bottom" class="white" style="padding-bottom: 8; background: #345B80; background-image: url('images/footer_bar.gif'); background-repeat:no-repeat;">
						<!-- DO NOT REMOVE THIS COPYRIGHT! -->
						<center> Copyright <a href="http://www.pdkwebs.nl" target="_blank">Aaxklonp</a> & <a href="http://www.bhotradio.com" target="_blank">Cootje</a> 2010. All rights reserved.<br><br></center>
					</td>
				</tr>
			</table>
		</td>
		<td width="31" background="images/right_shadow.gif">
		</td>
	</tr>
</table>
</td>
</tr>
</table>
</body>
</html>