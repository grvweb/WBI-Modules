<?php

##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
# 																			 #
# YOU MUST AGREE TO THE FOLLOWING DISCLAIMER...                          	 #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.	                             #
# 																			 #
##############################################################################
# 																			 #
# This ZPanel Analyzer is written by Marco (Cootje) and Patrick (Aaxklonp).	 #
# All copyright goes to Marco and Patrick.									 #
# 																			 #
# If you have questions about installing or using this script, you can		 #
# always mail us: zpanel@pdkwebs.nl. NO SPAM please.						 #
# 																			 #
# Best regards, have fun with your hosting,									 #
# 																			 #
# Marco (Cootje) and Patrick (Aaxklonp).									 #
##############################################################################

?>
<?php
require "config.php";
$host = $database_host;
$username = $database_user;
$password = $database_password;
$db_name="zpanel_core";
$tbl_name="z_accounts";
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");
$myusername=$_POST['myusername'];
$mypassword=$_POST['mypassword'];
$encrypted_mypassword=md5($mypassword);
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysql_real_escape_string($myusername);
$mypassword = mysql_real_escape_string($mypassword);
$sql="SELECT * FROM $tbl_name WHERE ac_user_vc='$myusername' and ac_pass_vc='$encrypted_mypassword'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);
if($count==1){
session_register("myusername");
session_register("mypassword");
header("location:login_success.php");
}
else {

}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<head>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

</head>
<body  bgcolor="#FFFFFF" leftMargin="0" rightMargin="0" topMargin="0" bottomMargin="0">
<table height="100%" width="100%" cellpadding="0" cellspacing="0">
<tr>
<td align="center">
<table height="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td height="100%" width=31 background="images/left_shadow.gif" valign="bottom">
			<img src="images/left_shadow.gif">
		</td>
		<td  valign="top">
			<table width="100%" height="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td height="120" align="left" background="images/header_no.gif">
					<img src="images/header.jpg" height="120" width="800"></td>
				</tr>
				<tr>
					<td height="100%" valign="top" background="images/inner_bg.gif">
						<table width="100%" height="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="202" valign="top" height="1">
									<table width="100%" height="100%" cellpadding="0" cellspacing="0" class="main">
									<tr><td class="mainlayout" valign="top" style="padding-bottom: 0px;">
									<br /><img src="images/menu.jpg">
								<table cellSpacing="0" cellPadding="4" width="100%">
									<tbody>
										<tr>
											<td align="middle">
											<table border="0" cellSpacing="0" vAlign="top" cellPadding="0" width="100%">
													<tr>
														<td>
<ul id="nav"> 
  <li><a href="index.php">Home</a></li> 
</ul>
 <br /><br />
														</td>
													</tr>
													</table>
											</td>
										</tr>
								</table>
									</td></tr>				
									</table>
								</td>
								<td style="background: #FFFFFF; " align="center">

<?php
echo "<title>ZPanel Analyzer - Login</title>
<meta HTTP-EQUIV=\"REFRESH\" content=\"2; url=index.php\">
<h2>Wrong Username or Password</h2>";
?>

</td>
							</tr>
						</table>
</td>
				</tr>
				<tr>
					<td height="50 align="center valign="bottom" class="white" style="padding-bottom: 8; background: #345B80; background-image: url('images/footer_bar.gif'); background-repeat:no-repeat;">
						<!-- DO NOT REMOVE THIS COPYRIGHT! -->
						<center> Copyright <a href="http://www.pdkwebs.nl" target="_blank">Aaxklonp</a> & <a href="http://www.bhotradio.com" target="_blank">Cootje</a> 2010. All rights reserved.<br><br></center>
					</td>
				</tr>
			</table>
		</td>
		<td width="31" background="images/right_shadow.gif">
		</td>
	</tr>
</table>
</td>
</tr>
</table>
</body>
</html>