<?php

##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
# 																			 #
# YOU MUST AGREE TO THE FOLLOWING DISCLAIMER...                          	 #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.	                             #
# 																			 #
##############################################################################
# 																			 #
# This ZPanel Analyzer is written by Marco (Cootje) and Patrick (Aaxklonp).	 #
# All copyright goes to Marco and Patrick.									 #
# 																			 #
# If you have questions about installing or using this script, you can		 #
# always mail us: zpanel@pdkwebs.nl. NO SPAM please.						 #
# 																			 #
# Best regards, have fun with your hosting,									 #
# 																			 #
# Marco (Cootje) and Patrick (Aaxklonp).									 #
##############################################################################

session_start();
if(!session_is_registered(myusername)){
header("location:login.php");
}
?>
<title>ZPanel Analyzer - FTP Accounts: <?php echo"$user"; ?></title>
<?php
echo "<a href=\"javascript:history.back()\" 
onMouseOver=\"document.mouseover.src=image2.src\" onMouseOut=\"document.mouseover.src=image1.src\"> 
<img src=\"images/return.png\" border=0 name=\"mouseover\"></a> 
</a><br />
<table width='100%' cellspacing='2' border='0' bgcolor='#F1F1F1' class='white' >
<tr bgcolor='#007DC5'>
<td><a href=\"?p=details&username=$user\"><center><b>Details</b></center></a></td>
<td><a href=\"?p=domain&username=$user\"><center><b>Domains</b></center></a></td>
<td><a href=\"?p=usage&username=$user\"><center><b>Bandwidth/Diskspace</b></center></a></td>
<td><a href=\"?p=mysql&username=$user\"><center><b>MySQL Databases</b></center></a></td>
<td><a href=\"?p=ftpaccs&username=$user\"><center><b>FTP Accounts</b></center></a></td>
</tr>
</table>";
?>
<?php
$result = mysql_query("SELECT 
ac_id_pk-1 AS '', ac_user_vc AS '<b>Username</b>', ft_user_vc AS '<b>FTP Username</b>', 
ft_directory_vc AS '<b>Directory</b>' from z_accounts, z_ftpaccounts WHERE ac_user_vc != 'tasksys' AND ft_deleted_ts IS NULL AND ac_id_pk = 
ft_acc_fk AND ac_user_vc = '{$user}' ORDER BY ac_id_pk");
if (!$result) {
    die("Query to show fields from table failed");
}
$fields_num = mysql_num_fields($result);
echo "<h2>FTP Accounts</h2>";
echo "<table width='100%' cellspacing='2' border='0' bgcolor='#F1F1F1'><tr>";
for($i=0; $i<$fields_num; $i++)
{
    $field = mysql_fetch_field($result);
    echo "<td bgcolor=\"#007DC5\" class='white'>{$field->name}</td>";
}
echo "</tr>\n";
while($row = mysql_fetch_row($result))
{
    echo "<tr>";
    foreach($row as $cell)
        echo "<td>$cell</td>";
    echo "</tr>\n";
}
mysql_free_result($result);
echo "";
?>
</table><br>
<a href="javascript:history.back()" 
onMouseOver="document.mouseover2.src=image2.src" onMouseOut="document.mouseover2.src=image1.src"> 
<img src="images/return.png" border=0 name="mouseover2"></a> 
</a>