<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
# 																			 #
# YOU MUST AGREE TO THE FOLLOWING DISCLAIMER...                          	 #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.	                             #
# 																			 #
##############################################################################
# 																			 #
# This Auto Signup is written by Marco (Cootje) and Patrick (Aaxklonp).		 #
# All copyright goes to Marco and Patrick.									 #
# 																			 #
# If you have questions about installing or using this script, you can		 #
# always mail us: zpanel@pdkwebs.nl. NO SPAM please.						 #
# 																			 #
# Best regards, have fun with your hosting,									 #
# 																			 #
# Marco (Cootje) and Patrick (Aaxklonp).									 #
##############################################################################




session_start();
include "config.php";
$link = mysql_connect("$z_db_host", "$z_db_user", "$z_db_pass") or die(mysql_error());
echo "";
$db_selected = mysql_select_db ("$z_db_name", $link);
if (!$db_selected) {
	die ('MySQL Error: ' .mysql_error());
}
else {
echo "";
}

$useraccount = "2";
$sql = "SELECT * FROM z_accounts WHERE ac_reseller_fk=" .$useraccount['ac_id_pk']. " AND ac_deleted_ts IS NULL";

?>
<script language="javascript">
function checkform(form) {
    for (var x=0; form.elements[x]; x++ ) {
        if (form.elements[x].value == ""){
            if(form.elements[x].id != "nocheck") {
            alert( "Please " + form.elements[x].id + "." );
            form.elements[x].focus();
            return false ;
            }
        }
    }       
}
</script>
<?php  
function createRandomPassword() {  
$chars = "abcdefghijkmnopqrstuvwxyz023456789";     
srand((double)microtime()*1000000);     
$i = 0;     $pass = '' ;  
while ($i <= 7) {         
$num = rand() % 33;         
$tmp = substr($chars, $num, 1);         
$pass = $pass . $tmp;         
$i++;     
}     
return $pass;  
}  
$passwordg = createRandomPassword(); 
?>
<h3>Create new account</h3>
<form onsubmit="return checkform(this)" id="frmClients" name="frmClients" method="post" action="runner.php">
<table>
  <tr>
    <td>Username:</td>
    <td><input type="text" name="inUserName" id="fill in your username" maxlength="10" value="" /></td>
  </tr>
<tr>
 <td><input type="hidden" name ="inPackage" id="inPackage" value="2" />
<input type="hidden" name ="inPassWord" id="inPassWord" value="<?php echo "$passwordg" ?>" /></td>
   </tr>
  <tr>
    <td>Full name: </td>
    <td><input type="text" name="inFullName" id="fill in your full name" /></td>
  </tr>
  <tr>
    <td>Email: </td>
    <td><input type="text" name="inEmailAddress" id="fill in your email address" /></td>
  </tr>
  <tr>
    <td>Site category:</td>
	<td>
<select name="Category" id="nocheck">
<option>Personal</option>
<option>Business</option>
<option>Hobby</option>
<option>Blog</option>
<option>Forum</option>
<option>Software</option>
</select></td>
<tr><td>Do you accept our <a href="<?php echo "$UserAgreementURL" ?>"><br />User Agreement?</a>:</td>
<td><select name="inAgree" size="1" id="accept our User Agreement">
<option value="">No</option>
<option value="Yes">Yes</option>
</select></tr>
  <tr>
    <td><input name="inSWE" type="hidden" id="inSWE" value="1" checked="checked" /></td>
  </tr>
  <tr>
    <td>Security Code:</td>
    <td><img id="siimage" align="left" style="padding-right: 5px; border: 0" src="secure/securimage_show.php?sid=<?php echo md5(time()) ?>" /><a tabindex="-1" style="border-style: none" href="#" title="Refresh Image" onclick="document.getElementById('siimage').src = 'secure/securimage_show.php?sid=' + Math.random(); return false"><img src="refresh.gif" alt="Reload Image" border="0" onclick="this.blur()" align="bottom" /></a></td>
  </tr>
  <tr>
    <td>Code:</td>
    <td><input type="text" name="code" id="enter the secure code" /></td>
  </tr>
  <tr>
      <th colspan="2" align="right">
      <input type="hidden" name="inAction" value="new" />

 <input type="submit" name="inSubmit" id="inSubmit" value="Register" />
      </td>
  </tr>
</table>
</form>
</html>