<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
# 																			 #
# YOU MUST AGREE TO THE FOLLOWING DISCLAIMER...                          	 #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.	                             #
# 																			 #
##############################################################################
# 																			 #
# This Auto Signup is written by Marco (Cootje) and Patrick (Aaxklonp).		 #
# All copyright goes to Marco and Patrick.									 #
# 																			 #
# If you have questions about installing or using this script, you can		 #
# always mail us: zpanel@pdkwebs.nl. NO SPAM please.						 #
# 																			 #
# Best regards, have fun with your hosting,									 #
# 																			 #
# Marco (Cootje) and Patrick (Aaxklonp).									 #
##############################################################################


  include("secure/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['code']);
  if($valid == true) {
  echo "";
  } else {
    die ("Sorry, the code you entered was invalid.  <a href=\"javascript:history.go(-1)\">Go back</a> to try again.");
  }
include "config.php";
$link2 = mysql_connect("$z_db_host", "$z_db_user", "$z_db_pass") or die(mysql_error());
echo "";
$db_selected2 = mysql_select_db ("$z_db_name", $link2);
if (!$db_selected2) {
	die ('MySQL Error: ' .mysql_error());
}
else {
echo "";
}
$inAgree = $_POST['inAgree'];
$UserName = $_POST['inUserName'];
$PassWord = $_POST['inPassWord'];
$Package = $_POST['inPackage'];
$FullName = $_POST['inFullName'];
$Email = $_POST['inEmailAddress'];
$Category = $_POST['Category'];
$PassWordMD5 = md5($PassWord);
$Date = date('jmyhis');
$Date2 = date('j m y h i s');
$ipi = getenv("REMOTE_ADDR");

if ( $inAgree != "Yes" ) {
echo "<h2>You must accept our User Agreement to signup!</h2><br />";
die ("<h2><a href=\"javascript:history.back()\">Return to registration</a></h2><p />");
} else {
	echo "";
}
if(!$Email == "" && (!strstr($Email,"@") || !strstr($Email,".")))
{
echo "<h2>Please fill in a working email address!</h2><br />";
die ("<h2><a href=\"javascript:history.back()\">Return to registration</a></h2><p />");
}
if(empty($UserName) || empty($FullName) || empty($Email)) {
echo "<h2>Please fill in all fields!</h2><br />";
die ("<h2><a href=\"javascript:history.back()\">Return to registration</a></h2><p />");
}
$checkuser = "SELECT ap_email_vc FROM z_personal WHERE ap_email_vc='$Email'"; 
$query = mysql_query($checkuser); 
if ( mysql_num_rows($query) >= 1 ) { 
echo "<h2>Your email address already exists. Please choose another.</h2><br />"; 
die ("<h2><a href=\"javascript:history:back()\">Return to registration</a></h2>");
}  
$checkuser = "SELECT ip FROM z_personal WHERE ip='$ipi'"; 
$query = mysql_query($checkuser); 
if ( mysql_num_rows($query) >= 1 ) { 
echo "<h2>You can only register once with one IP address!</h2><br />"; 
die ("<h2><a href=\"$\">Return to registration</a></h2>");
}  
$checkuser = "SELECT ac_user_vc FROM z_accounts WHERE ac_user_vc='$UserName'"; 
$query = mysql_query($checkuser); 
if ( mysql_num_rows($query) >= 1 ) { 
echo "<h2>Your username already exists. Please choose another.</h2><br />"; 
die ("<h2><a href=\"javascript:history:back()\">Return to registration</a></h2>");
}
if ( $smtp_yn == 1 ) {
include "sendmail.php";
} else {
	echo "";
}
$result44=mysql_query("SELECT category FROM z_personal;");
if (mysql_errno())
{
@mysql_query("ALTER TABLE `z_personal` ADD `category` VARCHAR( 100 )") or die(mysql_error());
}
else
{
echo "";
}
$result45=mysql_query("SELECT ip FROM z_personal;");
if (mysql_errno())
{
@mysql_query("ALTER TABLE `z_personal` ADD `ip` VARCHAR( 100 )") or die(mysql_error());
}
else
{
echo "";
}
//MySQL Adding starts here
include "included.php";
mysql_query("INSERT INTO z_personal (ap_id_pk, ap_acc_fk, ap_fullname_vc, ap_email_vc, ip, category)
VALUES ('$ap_id_pk1', '$ap_acc_fk1', '$FullName', '$Email', '$ipi', '$Category')");
mysql_query("INSERT INTO z_accounts (ac_id_pk, ac_user_vc, ac_pass_vc, ac_package_fk, ac_reseller_fk, ac_created_ts)
VALUES ('$ac_id_pk1', '$UserName', '$PassWordMD5', '$Package', '2', '$Date')");

mysql_query("INSERT INTO mysql.user (Host, User, Password) VALUES ('%', '$UserName', PASSWORD('$PassWord'))");
mysql_query("FLUSH PRIVILEGES");
mysql_query("INSERT INTO mysql.db (Host, Db, User, Select_priv, Insert_priv, Update_priv, Delete_priv, Create_priv, Drop_priv, Grant_priv, References_priv, Index_priv, Alter_priv, Create_tmp_table_priv, Lock_tables_priv, Create_view_priv, Show_view_priv, Create_routine_priv, Alter_routine_priv, Execute_priv, Event_priv, Trigger_priv) VALUES ('%', '$UserName\_%', '$UserName', 'Y', 'Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y')");
mysql_query("FLUSH PRIVILEGES");

$currentdate = date("Ym");
mysql_query("INSERT INTO z_bandwidth (bd_acc_fk, bd_month_in, bd_transamount_bi, bd_diskamount_bi) VALUES ('$ac_id_pk1', '$currentdate', '0', '0')");

//Userdir adding starts here (and logs)
mkdir("$user_root/$UserName", 0777);
mkdir("$zpanel_logs/domains/$UserName", 0777);
include "succeeded.php";
?>