<?php
# This module is made for ZPanel 5.0.1, 5.0.2 and maybe some more versions.
# Editing is allowed, but distributing under another name is NOT!
# This module is FREE of charche!

##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
# 																			 #
# YOU MUST AGREE TO THE FOLLOWING DISCLAIMER...                          	 #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.	                             #
# 																			 #
##############################################################################
# 																			 #
# This Auto Signup is written by Marco (Cootje) and Patrick (Aaxklonp).		 #
# All copyright goes to Marco and Patrick.									 #
# 																			 #
# If you have questions about installing or using this script, you can		 #
# always mail us: zpanel@pdkwebs.nl. NO SPAM please.						 #
# 																			 #
# Best regards, have fun with your hosting,									 #
# 																			 #
# Marco (Cootje) and Patrick (Aaxklonp).									 #
##############################################################################

//EDIT from here\\

//ZPanel details (also located in C:/ZPanel/Panel/conf/zcnf.php)
$user_root = "C:/ZPanel/hostdata";					// Normally this is C:/ZPanel/hostdata (no '/' at the end)
$zpanel_logs = "C:/ZPanel/logs";					// Should be C:/ZPanel/logs if nothing is changed.
$z_db_host = "127.0.0.1";							// Mostly 'localhost' or '127.0.0.1'. Can also be another IP.
$z_db_name = "zpanel_core";							// DB. Normally zpanel_core.
$z_db_user = "root";								// The MySQL main user account name.
$z_db_pass = "";									// The MySQL main user account password.
$site_URL = "";										// The full URL of your web hosting site.
$UserAgreementURL = "";  							// URL to your user agreement.
$zdb = @mysql_pconnect($z_db_host, $z_db_user, $z_db_pass) or trigger_error('ZPanel Stack Error :: Unable to connect to ZPanel Database Server (' .$z_db_host. ').'); // Don't change this please.

//SMTP mailer details
$smtp_yn = "1";						// If you want to use smtp (highly recommended!) use '1'. Else use '0'.
# If you don't want to use smtp, no mails will be send. Then you won't have to configure the config_mail.php.
?>