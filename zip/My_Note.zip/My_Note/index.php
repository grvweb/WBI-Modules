<?php
ob_start();
session_start();
include('modules/account/My_Note/modinfo.zp.php');
$file = $hostdata . $_SESSION['zUsername'] . '/' . $_SESSION['zUsername'] . "_MyNote.txt";

//
if(file_exists($file)){
$hope = file_get_contents($file); 
}else{
$fp = fopen($hostdata . $_SESSION['zUsername'] . '/' . $_SESSION['zUsername'] . "_MyNote.txt", "w");
$hope = 'add content here and click save';
}

?>

<form id="form1" name="form1" method="post" action="/modules/account/My_Note/write.php" >
  <p>&nbsp;</p>
  <table width="422" border="0" align="center" cellpadding="30" cellspacing="10" background="modules/account/My_Note/block_bg.gif">
    <tr>
      <th width="402" scope="row">
        <textarea name="hello" cols="30" rows="16" wrap="off" dir="ltr"  id="text" background-color="transparent" style="border: 0"><?php echo $hope; ?></textarea>
        
        <br/>
          <input name="save" type="submit" value="save" />
      </th>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>

<p>
MyNote this is to write and edit notes.
</p>
<p>
if you wish to take a backup file go to your file manager and find the file <?php echo $_SESSION['zUsername'] . '_MyNote.txt';?> and download it!
</p>
