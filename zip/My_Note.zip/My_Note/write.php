<?php 
include('modinfo.zp.php');
session_start();
//get the posted data
$your_data = $_POST['hello'];
// Open the file and erase the contents if any
$fp = fopen($hostdata . $_SESSION['zUsername'] . '/' . $_SESSION['zUsername'] . "_MyNote.txt", "w");
// Write the data to the file
fwrite($fp, $your_data);
// Close the file
fclose($fp);
//redirect back to zpanel mynote module
header( 'Location: ../../../?c=account&p=My_Note' ) ;
?>