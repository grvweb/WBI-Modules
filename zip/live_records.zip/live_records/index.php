<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
#     3) AGREE TO THE FOLLOWING DISCLAIMER...                                #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                 #
##############################################################################
?>
<h3>System Live Records</h3>								
<?php

$result43=mysql_query("SELECT category FROM z_personal;");
if (mysql_errno())
{
@mysql_query("ALTER TABLE `z_personal` ADD `category` VARCHAR( 100 )") or die(mysql_error());
}
else
{
echo "";
}
$result45=mysql_query("SELECT ip FROM z_personal;");
if (mysql_errno())
{
@mysql_query("ALTER TABLE `z_personal` ADD `ip` VARCHAR( 100 )") or die(mysql_error());
}
else
{
echo "";
}

?>
<table width='100%' cellspacing='2' border='0' bgcolor='#F1F1F1'>
	<tr>
		<td bgcolor="#007DC5" width="70%" class="white"><b>Total Users Created</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$totalclientss=mysql_query("SELECT COUNT(ac_user_vc) AS 'Users' from z_accounts WHERE ac_user_vc != 'tasksys'");
				$totalclients=mysql_result($totalclientss,0,"Users");
				echo "$totalclients User(s)";
			?>
		</td>
	</tr>
	<tr>
		<td bgcolor="#007DC5" width="70%" class="white"><b>Total Users Actived | Banned</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$result5=mysql_query("SELECT COUNT(ac_user_vc) AS 'Users' from z_accounts WHERE ac_user_vc != 'tasksys' AND ac_deleted_ts IS NULL");
				$total5=mysql_result($result5,0,"Users");
				$banned=($totalclients - $total5);
				echo "$total5 | $banned User(s)";
			?>
		</td>
	</tr>
	<tr>
		<td bgcolor="#007DC5" width="50%" class="white"><b>Total Domains</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$result6=mysql_query("SELECT COUNT(vh_type_in) AS 'Domains' from z_vhosts WHERE vh_type_in = '1' AND vh_deleted_ts IS NULL");
				$total6=mysql_result($result6,0,"Domains");
				echo "$total6 Domain(s)";
			?>
		</td>
	</tr>
	<tr>
		<td bgcolor="#007DC5" width="50%" class="white"><b>Total Subdomains</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$result7=mysql_query("SELECT COUNT(vh_type_in) AS 'SubDomains' from z_vhosts WHERE vh_type_in = '2' AND vh_deleted_ts IS NULL");
				$total7=mysql_result($result7,0,"SubDomains");
				echo "$total7 Subdomain(s)";
			?>
		</td>
	</tr>
	<tr>
		<td bgcolor="#007DC5" width="50%" class="white"><b>Total FTP Accounts</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$result4=mysql_query("SELECT COUNT(ft_user_vc) AS 'FtpAccs' from z_ftpaccounts WHERE ft_deleted_ts IS NULL");
				$total4=mysql_result($result4,0,"FtpAccs");
				echo "$total4 Account(s)";
			?>
		</td>
	</tr>
	<tr>
		<td bgcolor="#007DC5" width="50%" class="white"><b>Total MySQL Databases&nbsp;</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$result8=mysql_query("SELECT COUNT(my_name_vc) AS 'MySQLdb' from z_mysql WHERE my_deleted_ts IS NULL");
				$total8=mysql_result($result8,0,"MySQLdb");
				echo "$total8 Database(s)";
			?>
		</td>
	</tr>
	<tr>
		<td bgcolor="#007DC5" width="50%" class="white"><b>Total Used Bandwidth</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$result3=mysql_query("SELECT ROUND(SUM(bd_transamount_bi/10240000000), 2) AS 'Bandwidth' from z_bandwidth, z_accounts");
				$total3=mysql_result($result3,0,"Bandwidth");
				echo "$total3 GB";
			?>
		</td>
	</tr>
	<tr>
		<td bgcolor="#007DC5" width="50%" class="white"><b>Total Used Diskspace</b></td>
		<td bgcolor="#F1F1F1">
			<?php
				$resultt=mysql_query("SELECT bd_month_in AS 'LastMonth' from z_bandwidth ORDER BY LastMonth DESC LIMIT 1");
				$LastMonth=mysql_result($resultt,0,"LastMonth");
			?>
			<?php
				$resultv=mysql_query("SELECT SUM(ROUND(bd_diskamount_bi/1024000000, 2)) AS 'TotalDiskamount' from z_bandwidth WHERE bd_month_in = '{$LastMonth}'");
				$totalv=mysql_result($resultv,0,"TotalDiskamount");
				echo "$totalv GB";
			?>
		</td>
	</tr>
</table>