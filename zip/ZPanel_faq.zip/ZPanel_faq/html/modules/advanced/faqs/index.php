<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# BY USING THIS SOFTWARE/SCRIPT OR ANY FUNCTION PROVIDED IN THE SOURCE CODE  #
# YOU AGREE THAT YOU MUST NOT DO THE FOLLOWING:-                             #
#                                                                            #
#     1) REMOVE THE COPYRIGHT INFOMATION                                     #
#     2) RE-PACKAGE AND/OR RE-BRAND THIS SOFTWARE                            #
#     3) AGREE TO THE FOLLOWING DISCLAIMER...                                #
#                                                                            #
# DISCLAIMER                                                                 #
# -------------------------------------------------------------------------- #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED  #
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR #
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR           #
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,      #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,        #
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;#
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,   #
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    #
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF     #
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                 #
##############################################################################

//Check admin status and enable variables if true
if ($_SESSION['zUsername'] == "zadmin"){
$question = $_POST["question"];
$answer = $_POST["answer"];
$faqid = $_POST["faqid"];
	if (!empty($_POST['question']) && !empty($_POST['answer'])){addfaq($question, $answer);}
	if (!empty($_POST['faqid'])){updatefaq($faqid);}
}

//Main display
display_faqs();

//Change display to function so changes are refreshed automatically
function display_faqs(){

include('conf/zcnf.php');
include('lang/' .GetSystemOption('zpanel_lang'). '.php');

#Get a list of the FAQ's from the database
$sql = "SELECT * FROM z_faqs WHERE fq_queston_tx IS NOT NULL";
$listfaqs = DataExchange("r",$z_db_name,$sql);
$rowfaqs = mysql_fetch_assoc($listfaqs);
echo'
<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == \'none\')
          e.style.display = \'block\';
       else
          e.style.display = \'none\';
    }
//-->
</script>
';
echo $lang['50'];
echo'<blockquote>
<table>';
do{

echo' <tr valign="top">
    	<td>';
	//Admin delete faqs
	if ($_SESSION['zUsername'] == "zadmin"){
		echo '
		<form name="updatefaq" method="post" action="'.GetFullURL().'">
		<input type="image" src="modules/advanced/faqs/Delete-icon_small.png" value="Submit" alt="DELETE FAQ">&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="hidden" name="faqid" value="'.$rowfaqs['fq_id_pk'].'"></td><td>
		</form>
		';
	} 
		
	echo'
	<img src="modules/advanced/FAQs/item.png" width="16" height="16"></td>
    	<td>
		<a href="#" onclick="toggle_visibility(\''.$rowfaqs['fq_id_pk'].'\');"><strong>'.Cleaner('o',$rowfaqs['fq_queston_tx']).'</strong></a>
		<div id="'.$rowfaqs['fq_id_pk'].'" style="display:none;">'.Cleaner('o',$rowfaqs['fq_answer_tx']).'<br><br></div>
		</td>
 	 </tr>';
} while ($rowfaqs = mysql_fetch_assoc($listfaqs));
	
echo'
</table>	
</blockquote>';
}

//Admin add faqs
if ($_SESSION['zUsername'] == "zadmin"){	
	echo'<br><br><hr>
	<form name="addfaq" method="post" action="'.GetFullURL().'">
	<b>Admin FAQ Edit:</b><br><br>
	<table>
 	 <tr>
 		<td>Question:<br><input type="text" name="question" style="width: 325px;"><br><br>
		Answer:<br><textarea rows="5" cols="40" name="answer"></textarea><br><br>
		<input type=submit value="Add FAQ Item"></td>		
 	 </tr>
	</table>
	</form>
	';
}

//Faq Functions for adding and deleting
function addfaq($question, $answer){
$result = mysql_query("INSERT INTO z_faqs (`fq_queston_tx`, `fq_answer_tx`) VALUES ('$question', '$answer')");
echo '<font color="green">FAQ Item Added</font><BR><BR>';
}

function updatefaq($faqid){
$result = mysql_query("DELETE FROM z_faqs WHERE `fq_id_pk` = '$faqid'");
echo '<font color="red">FAQ Item DELETED</font><BR><BR>';
}
	
?>