<?php
##############################################################################
# ZPanel - A free to use hositng control panel for Microsoft(R) Windows(TM)  #
# Copyright (C) Bobby Allen  & The ZPanel Development team, 2009-Present     #
# Email: ballen@zpanel.co.uk                                                 #
# Website: http://www.zpanel.co.uk                                           #
# -------------------------------------------------------------------------- #
# ZPANEL MODULE CONFIGURATION FILE                                           #
##############################################################################
/***********************************************************************
* Module name:            Simple Support System                        *
* Module author:          Andy Phillips (shadow13)                     *
* Module author:          T Gates (sgtmudd)                            *
* Module website:         http://www.ossdc.net/project.php?project=sss *
* Module author email:    techman@illumina-illume.com                  *
* Module author email:    tgates@mach-hosting.com                      *
* Module first released:  01/17/2010                                   *
* Module version:         v0.7-01/20/2010                              *
* Module v5 conversion:   v5.0.1-02/010/2010 (by sgtmudd)              *
* Module Last Update:     v5.0.2-07/21/2010 (by TGates)                *
* NOTICE: You may edit these files as you wish, but this notice MUST   *
* remain in ALL files associated with this package!                    *
***********************************************************************/

$thismod['title'] = 'Simple Support System';
$thismod['icon'] = 'operator.gif';
$thismod['developer'] = 'TGates (sgtmudd) & APhilips (shadow13)';
$thismod['developersite'] = 'http://www.ossdc.net/project.php?project=sss';
?>