<?php
/***********************************************************************
* Module name:            Simple Support System                        *
* Module author:          Andy Phillips (shadow13)                     *
* Module author:          T Gates (sgtmudd)                            *
* Module website:         http://www.ossdc.net/project.php?project=sss *
* Module author email:    techman@illumina-illume.com                  *
* Module author email:    tgates@mach-hosting.com                      *
* Module first released:  01/17/2010                                   *
* Module version:         v0.7-01/20/2010                              *
* Module v5 conversion:   v5.0.1-02/010/2010 (by sgtmudd)              *
* Module Last Update:     v5.0.2-07/21/2010 (by TGates)                *
* NOTICE: You may edit these files as you wish, but this notice MUST   *
* remain in ALL files associated with this package!                    *
***********************************************************************/
$adminemail = $_POST['adminemail'];
$msgheader = $_POST['msgheader'];
$ip = $_POST['ip'];
$httpref = $_POST['httpref'];
$httpagent = $_POST['httpagent'];
$visitor = $_POST['visitor'];
$visitormail = $_POST['visitormail'];
$msgcontent = $_POST['msgcontent'];
$attn = $_POST['attn'];
if (eregi('http:', $msgcontent)) {
die ("<center>Do NOT try that! ! </center>");
}
if(!$visitormail == "" && (!strstr($visitormail,"@") || !strstr($visitormail,".")))
{

echo "<center><h2>Go Back - Enter a valid e-mail address.</h2>\n";
$badinput = "<h2>Feedback was NOT submitted</h2>\n";
echo $badinput;
die ("<FORM><INPUT TYPE=\"button\" VALUE=\"Back\" onClick=\"history.go(-1);return true;\"> </FORM> </center>");
}
if(empty($visitor) || empty($visitormail) || empty($msgcontent )) {
echo "<center><h2>Go Back - fill in all fields!</h2>\n";
die ("<FORM><INPUT TYPE=\"button\" VALUE=\"Back\" onClick=\"history.go(-1);return true;\"> </FORM> </center>");
}
if(!$attn == (!strstr($attn,"@") || !strstr($attn,"."))) {
 $adminemail = $attn;
}
include("config_settings.php");

$attn = $attn;
$subject = $attn;
$msgcontent = stripcslashes($msgcontent);
$todayis = date("l, F j, Y, g:i a") ;
// $message was here
$from = "From: $visitormail\r\n";
$emailto = "$adminemail, $visitormail";
mail($emailto, $subject, $message, $from, $headers);
// mail send Thanking pop-up
echo "<script language=\"javascript\" type=\"text/javascript\">
alert('Thank You, We will contact you shortly.   A copy was also sent to the email you provided.');
window.location = \"http://$_SERVER[HTTP_HOST]\";
</script>";
?>