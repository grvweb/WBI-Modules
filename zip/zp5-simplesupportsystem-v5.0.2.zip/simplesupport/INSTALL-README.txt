/***********************************************************************
* Module name:            Simple Support System                        *
* Module author:          Andy Phillips (shadow13)                     *
* Module author:          T Gates (sgtmudd)                            *
* Module website:         http://www.ossdc.net/project.php?project=sss *
* Module author email:    techman@illumina-illume.com                  *
* Module author email:    tgates@mach-hosting.com                      *
* Module first released:  01/17/2010                                   *
* Module version:         v0.7-01/20/2010                              *
* Module v5 conversion:   v5.0.1-02/010/2010 (by sgtmudd)              *
* Module Last Update:     v5.0.2-07/21/2010 (by TGates)                *
* NOTICE: You may edit these files as you wish, but this notice MUST   *
* remain in ALL files associated with this package!                    *
***********************************************************************/

ABOUT THIS MODULE
=================
This module intergrates a simple support system which for the
moment uses only email support. The client enters the info and clicks submit 
and an email is sent to the admin (and a copy is also sent to the client) with the submited info.
This new version can either send to one email account with different departments, or send to different emails for each department (or BOTH!).
Support can be found on the ZPanel forums. (http://forums.zpanel.co.uk)


NEW INSTALLATION:
=================
1 - Upload simplesupport folder to C:\ZPanel\panel\modules\account\
2 - Using you favorite PHP/txt editor open the (C:\ZPanel\panel\modules\simplesupport\config_settings.php) and update the settings.
	-There are two example lines for the Department settings.
	-You can enter either Department names or Email accounts, or BOTH!! Just remember to separate 	each entry with a comma ','
    -You can also configure the sent email message layout in the config_settings.php
3 - ADD the following lines to the end of your language files and edit as needed: ('C:/ZPanel/panel/lang/en-us.php' for example)

## Simple Support System Text START ##
$lang['sss0'] = "Simple Support System";
$lang['sss1'] = "Your Name";
$lang['sss2'] = "Your Email";
$lang['sss3'] = "Send Support Ticket To";
$lang['sss4'] = "Description of your problem";
$lang['sss5'] = "Required";
$lang['sss6'] = "SUBMIT";
$lang['sss7'] = "You will also receive an email of this request for your records.";
$lang['sss8'] = "Or";
$lang['sss9'] = "You can always find support and answers 24/7 by visiting our";
## Simple Support System Text END ##

4 - Login to your ZPanel and you should see the module icon.
5 - Click it.... and your away :)


UPGRADE FROM v5.0.1 TO v5.0.2:
==============================
A - RENAME: 'config_settings.php' (C:\ZPanel\panel\modules\simplesupport\config_settings.php) to 'config_settings_orig.php.
B - UPLOAD: ALL files overwriting original files.
C - EDIT: 'config_settings.php' with the information you entered in the original ('config_settings_orig.php')
D - DO STEP #3 ABOVE FOR NEW INSTALLATION to add the language variables.

*NOTE 

Report Bugs to: http://www.ossdc.net/project.php?project=sss (Free registration required to post)

More Updates To Come!! We Hope You Enjoy!

-Shadow13, SgtMudd