<?
/***********************************************************************
* Module name:            Simple Support System                        *
* Module author:          Andy Phillips (shadow13)                     *
* Module author:          T Gates (sgtmudd)                            *
* Module website:         http://www.ossdc.net/project.php?project=sss *
* Module author email:    techman@illumina-illume.com                  *
* Module author email:    tgates@mach-hosting.com                      *
* Module first released:  01/17/2010                                   *
* Module version:         v0.7-01/20/2010                              *
* Module v5 conversion:   v5.0.1-02/010/2010 (by sgtmudd)              *
* Module Last Update:     v5.0.2-07/21/2010 (by TGates)                *
* NOTICE: You may edit these files as you wish, but this notice MUST   *
* remain in ALL files associated with this package!                    *
***********************************************************************/
/*****************************************/
/* CONFIG SETTINGS                START  */
/*****************************************/
// Path to your website's support forums (NO 'HTTP://' or trailing slash '/' ie: yoursite.com/forums )
$supforum = 'mach-hosting.com/modules.php?name=Forums'; 
// Admin email that you want the support ticket sent to
$adminemail = 'no-reply@mach-network.com';
// Message header - between quotes (Leave blank for none)
$msgheader = 'SUPPORT_TICKET_ISSUED';
// Support categories or Email Accounts, separated by a comma ',' Add as many as you want!
$choices = array('Billing','Sales','Tech Support','TeamSpeak','E-Mail','Other');
//$choices = array('billing@mach-hosting.com','sales@mach-hosting.com','support@mach-hosting.com','ts@mach-hosting.com');
// Configure email message:
$message = "$msgheader\n
*************************************************************************\n
Message: $msgcontent \n
*************************************************************************\n
Additional Info : IP = $ip    Referral : $httpref \n
Browser Info: $httpagent \n
";
// Available variables that can be used in you message:
//
// $msgheader = Header Message inside email
// $msgcontent =   Message content
// $ip =        Clients IP
// $httpagent = Clients browser info
//
/*****************************************/
/* CONFIG SETTINGS                  END  */
/*****************************************/
?>