<?php
/***********************************************************************
* Module name:            Simple Support System                        *
* Module author:          Andy Phillips (shadow13)                     *
* Module author:          T Gates (sgtmudd)                            *
* Module website:         http://www.ossdc.net/project.php?project=sss *
* Module author email:    techman@illumina-illume.com                  *
* Module author email:    tgates@mach-hosting.com                      *
* Module first released:  01/17/2010                                   *
* Module version:         v0.7-01/20/2010                              *
* Module v5 conversion:   v5.0.1-02/010/2010 (by sgtmudd)              *
* Module Last Update:     v5.0.2-07/21/2010 (by TGates)                *
* NOTICE: You may edit these files as you wish, but this notice MUST   *
* remain in ALL files associated with this package!                    *
***********************************************************************/
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Simple Support System Ticket Form </title>
<Script Language="JavaScript">
function load() {
var load = window.open('modules/account/simplesupport/copyright.php','','scrollbars=no,menubar=no,height=300,width=400,resizable=no,toolbar=no,location=no,status=no');
}
</Script>
</head>
<body>
<?php
include('lang/' .GetSystemOption('zpanel_lang'). '.php');
include('modules/account/simplesupport/config_settings.php');
$ipi = getenv('REMOTE_ADDR');
$httprefi = getenv ('HTTP_REFERER');
$httpagenti = getenv ('HTTP_USER_AGENT');
$urlpre = 'http://';
?>
<B><?php echo $lang['sss0']; ?></B><br><br>
<form method="post" action="../modules/account/simplesupport/SSS-sendemail.php">
<input type="hidden" name="adminemail" value=<?php echo $adminemail ?> />
<input type="hidden" name="msgheader" value=<?php echo $msgheader ?> />
<input type="hidden" name="ip" value="<?php echo $ipi ?>" />
<input type="hidden" name="httpref" value="<?php echo $httprefi ?>" />
<input type="hidden" name="httpagent" value="<?php echo $httpagenti ?>" />
<?php echo $lang['sss1']; ?> (<?php echo $lang['sss5']; ?>):<br />
<input type="text" name="visitor" size="35" />
<br /><br>
<?php echo $lang['sss2']; ?> (<?php echo $lang['sss5']; ?>):<br />
<input type="text" name="visitormail" size="35" />
<br /><br />
<?php echo $lang['sss3']; ?>:<br>
<select name="attn">
<?php
foreach($choices as $value){
print("<option value=\"$value\">$value<option>");
}
?>
</option></select><br><br>
<?php echo $lang['sss4']; ?> (<?php echo $lang['sss5']; ?>):
<br /><textarea name="msgcontent" rows="4" cols="40"></textarea>
<br /><input type="submit" value="<?php echo $lang['sss6']; ?>"/>
<br></form>
<br><b><?php echo $lang['sss7']; ?></b>
<br><br><b><?php echo $lang['sss8']; ?></b><br><br>
<b><?php echo $lang['sss9']; ?> <? echo "<a href=".$urlpre . $supforum." target=\"_blank\">Support Forums.</a>" ?>
</b><br><br><br><br><br><br><br><br>
<a href="javascript:load()"><font size="1">Simple Support System v5.0.1 &copy; by sgtmudd &amp; shadow13</font></a>
</body>
</html>